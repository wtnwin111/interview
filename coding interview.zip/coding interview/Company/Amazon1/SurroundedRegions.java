/**
 * 
 */
package Amazon1;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author Tiannan
 *
 */
public class SurroundedRegions {
	 public static void solve(char[][] board) {
	        if (board == null || board.length == 0 || board[0].length == 0) {
	            return;
	        }
	        
	        int rows = board.length;
	        int cols = board[0].length;
	        
	        // the first line and the last line.
	        for (int j = 0; j < cols; j++) {
	            dfs(board, 0, j);
	            dfs(board, rows - 1, j);
	        }
	        
	        // the left and right column
	        for (int i = 0; i < rows; i++) {
	            dfs(board, i, 0);
	            dfs(board, i, cols - 1);
	        }
	        
	        // capture all the nodes.
	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	                if (board[i][j] == 'O') {
	                    board[i][j] = 'X';
	                } else if (board[i][j] == 'B') {
	                    board[i][j] = 'O';
	                }
	            }
	        }
	        
	        return;
	    }
	    
	public static void dfs(char[][] board, int i, int j) {
        int rows = board.length;
        int cols = board[0].length;
        
        // out of bound or visited.
        if (i < 0 || i >= rows || j < 0 || j >= cols) {
            return;
        }
        
        if (board[i][j] != 'O') {
            return;
        }
        
        board[i][j] = 'B';
        
        // dfs the sorrounded regions.
        dfs(board, i + 1, j);
        dfs(board, i - 1, j);
        dfs(board, i, j + 1);
        dfs(board, i, j - 1);
    }
	
	 public void solve1  (char[][] board) {
	        if (board == null || board.length == 0 || board[0].length == 0) {
	            return;
	        }
	        
	        int rows = board.length;
	        int cols = board[0].length;
	        
	        // the first line and the last line.
	        for (int j = 0; j < cols; j++) {
	            bfs(board, 0, j);
	            bfs(board, rows - 1, j);
	        }
	        
	        // the left and right column
	        for (int i = 0; i < rows; i++) {
	            bfs(board, i, 0);
	            bfs(board, i, cols - 1);
	        }
	        
	        // capture all the nodes.
	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	                if (board[i][j] == 'O') {
	                    board[i][j] = 'X';
	                } else if (board[i][j] == 'B') {
	                    board[i][j] = 'O';
	                }
	            }
	        }
	        
	        return;
	    }
	    
	    public void bfs1(char[][] board, int i, int j) {
	        int rows = board.length;
	        int cols = board[0].length;
	        
	        Queue<Integer> q = new LinkedList<Integer>();
	        q.offer(i * cols + j);
	        
	        while (!q.isEmpty()) {
	            int index = q.poll();
	            
	            // Index is out of bound.
	            if (index < 0 || index >= rows * cols) {
	                continue;
	            }
	            
	            int x = index / cols;
	            int y = index % cols;
	            
	            if (board[x][y] != 'O') {
	                continue;
	            }
	            
	            board[x][y] = 'B';
	            q.offer(index + 1);
	            q.offer(index - 1);
	            q.offer(index + cols);
	            q.offer(index - cols);
	        }
	    }
	    
	    public void bfs(char[][] board, int i, int j) {
	        int rows = board.length;
	        int cols = board[0].length;
	        
	        Queue<Integer> q = new LinkedList<Integer>();
	        q.offer(i * cols + j);
	        
	        while (!q.isEmpty()) {
	            int index = q.poll();
	            
	            int x = index / cols;
	            int y = index % cols;
	            
	            if (board[x][y] != 'O') {
	                continue;
	            }
	            
	            board[x][y] = 'B';
	            if (y < cols - 1) {
	                q.offer(index + 1);    
	            }
	            
	            if (y > 0) {
	                q.offer(index - 1);    
	            }
	            
	            if (x > 0) {
	                q.offer(index - cols);    
	            }
	            
	            if (x < rows - 1) {
	                q.offer(index + cols);    
	            }
	        }
	    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[][] a={
				{'X', 'X', 'X', 'X'},
				{'X', 'O', 'O', 'X'},
				{'X', 'X', 'O', 'X'},
				{'X', 'O', 'X', 'X'},
		};
		solve(a);
		for(int i=0; i<a.length;i++){
			for (int j=0; j<a[0].length;j++){
				System.out.print(a[i][j]+", ");
			}
			System.out.println();
		}
		
	}

}
