/**
 * 
 */
package Amazon1;

import java.util.ArrayList;

import tree.TreeNode;

/**
 * Given the root and two nodes in a Binary Tree. Find the lowest common ancestor(LCA) of the two nodes.

The lowest common ancestor is the node with largest depth which is the ancestor of both nodes.


Example 

For the following binary tree:
  4
 / \
3   7
   / \
  5   6


LCA(3, 5) = 4

LCA(5, 6) = 7

LCA(6, 7) = 7

 * @author Tiannan
 *
 */
public class LowestCommonAncestor {



	//Version 2: Divide & Conquer
	 // ��rootΪ���Ķ���������A,B��LCA:
    // ����ҵ��˾ͷ������LCA, if both sides are not null, return roo
    // ���ֻ����A���ͷ���A		if left is not null but right is null, return left 
    // ���ֻ����B���ͷ���B		if right is null but left is not null, return right 
    // �����û�У��ͷ���null		both are null return null



	private TreeNode getAncestor(TreeNode root, TreeNode node1, TreeNode node2) {
		if (root == null || root == node1 || root == node2) {
			return root;
		}

		// Divide
		TreeNode left = getAncestor(root.left, node1, node2);
		TreeNode right = getAncestor(root.right, node1, node2);

		// Conquer
		if (left != null && right != null) {
			return root;
		} 
		if (left != null) {
			return left;
		}
		if (right != null) {
			return right;
		}
		return null;
	}

	public TreeNode lowestCommonAncestor(TreeNode root, TreeNode node1, TreeNode node2) {
		if (node1 == null || node2 == null) {
			return null;
		}

		return getAncestor(root, node1, node2);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
