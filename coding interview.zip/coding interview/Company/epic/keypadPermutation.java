package epic;

import java.util.*;
/*
 * Phone has letters on the number keys. For example, 
 * number 2 has ABC on it, number 3 has DEF, 4 number has GHI,..., 
 * and number 9 has WXYZ. Write a program that will print out 
 * all of the possible combination of those letters depending 
 * on the input. 
 */
 
public class keypadPermutation{
	
	private static String[] map = {"","","ABC","DEF","GHI","JKL","MNO","PQRS","TUV","WXYZ"};
	
	public static void main(String[] args){
		for(String each:letterCombinations("23")){
			System.out.println(each);
		}
	}
	 public static List<String> letterCombinations(String digits) {
	        List<String> ret = new ArrayList<String>();
	        if (digits == null) {
	            return ret;
	        }
	        
	        dfs(digits, new StringBuilder(), ret, 0);
	        return ret;
	    }
	    
	    public static void dfs(String digits, StringBuilder sb, List<String> ret, int index) {
	        int len = digits.length();
	        if (index == len) {
	            ret.add(sb.toString());
	            return;
	        }
	        
	        // get the possiable selections.
	        String s = map[digits.charAt(index) - '0'];
	        for (int i = 0; i < s.length(); i++) {
	            sb.append(s.charAt(i));
	            dfs(digits, sb, ret, index + 1);
	            sb.deleteCharAt(sb.length() - 1);
	        }
	    }
	
}