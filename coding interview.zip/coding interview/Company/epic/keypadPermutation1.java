/**
 * 
 */
package epic;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Tiannan
 *
 */
public class keypadPermutation1 {
//	Given a digit string, return all possible letter combinations that the number could represent.
//
//			A mapping of digit to letters (just like on the telephone buttons) is given below.
//
//
//
//			Input:Digit string "23"
//			Output: ["ad", "ae", "af", "bd", "be", "bf", "cd", "ce", "cf"].
//			Note:
//			Although the above answer is in lexicographical order, your answer could be in any order you want.
	
/*	 void dfs(int ��ǰ״̬) {
		 2     if(��ǰ״̬Ϊ�߽�״̬) {
		 3         ��¼�����
		 4         return;
		 5     }
		 6     for(i=0;i<n;i++)    {    //�����������������ӽڵ�
		 7        //��չ��һ����״̬��
		 8        �޸���ȫ�ֱ���
		 9        if(��״̬����Լ������) {
		10           dfs(��״̬)
		11        }
		12         �ָ�ȫ�ֱ���//���ݲ���
		13     }
		14 }
		
		* array to map index to the string of keypad
		* dfs num to permu, index of current pos, stringbuffer for cach, result collection list of string
		* if 0 cond:index==len of num
		*  list .add buffer
		* return res;
		* string num= map[index]
		* for each num char variety from map[index]
		* 	buffer.append char
		* 	dfs (index+1, num, res, cache)
		* 	buffer del char back to upper level to do recursion
		*
		*/
	
	
	static String[] map={"","","ABC","DEF","GHI","JKL","MNO","PQRS","TUV","WXYZ"};
	public static List<String> keypadPermytation(String digits){
		List<String>res= new ArrayList<String>();
		if(digits==null){
			return res;
		}
		dfs(digits, new StringBuilder(), res, 0);
		return res;
	}
public static void dfs(String digits, StringBuilder sb, List<String> res, int index){
	int len= digits.length();
	if(index==len){
		res.add(sb.toString());
		return;
	}
	 // get the possiable selections.
	String num= map[digits.charAt(index)-'0'];
	for(int i=0; i<num.length();i++){
		sb.append(num.charAt(i));
		dfs(digits,sb, res,index+1);
		sb.deleteCharAt(sb.length()-1);
		
	}
}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(String each:keypadPermytation("23")){
			System.out.println(each);
		}
	}
	
}
