/**
 * 
 */
package epic;

/**
 * @author Tiannan
 *
 */
public class ValidPassword1 {
	/* Description: In 1-9 keypad one key is not working. If some one enters a password then 
	 * not working key will not be entered. You have given expected password and entered password.
	 * Check that entered password is valid or not 
	 * Ex: entered 164, expected 18684 (you need to take care as when u enter 
	 * 18684 and 164 only both will be taken as 164 input) 
	 * 
	 * input expected pw, input pw, the key missed
	 * loop cond: both exp and input pw
	 * if char i equal in exp and input, pinter i ++
	 *else if char i == key in exp and input, exp i++
	 *else false break
	 *
	 *if input has residue, then return false
	 *else if exp had residue, and rest are key then ture
	 *else false
	 * */
	public static boolean check(String exp, String in, int key){
		int i=0, j=0; boolean res = false;
		while(i<exp.length()&&j<in.length()){
			if(exp.charAt(i)==in.charAt(j)){
				res=true;j++;i++;
			}else if (Character.getNumericValue(exp.charAt(i))==key){
				i++;
			}else {
				res=false;
				break;
			}
		}
		
		if (i!=exp.length()||j!=in.length()){
			res=false;
		}
		return res;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(check("18684","164",8));
		System.out.println(check("1868488888","164",8));
	}

}
