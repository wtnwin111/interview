package epic;

/*
 * N*N matrix is given with input red or black.You can move horizontally, 
 * vertically or diagonally. If 3 consecutive same color found, that color 
 * will get 1 point. So if 4 red are vertically then point is 2. Find the winner.
 */

public class ticTacTow{
	public static void main(String[] args){
		
		char[][] m= { 
			{ 'r', 'r', 'r', 'b' }, 
			{ 'b', 'r', 'b', 'r' },
			{ 'b', 'r', 'r', 'b' }, 
			{ 'b', 'r', 'b', 'b' } 
		};System.out.println(m[1][0]);
		game(m);
	}

	public static void game(char[][] map){
		int score_red = check1(map,'r');
		int score_black = check1(map,'b');
		if(score_red>score_black){
			System.out.println("Red wins!");
		}else{
			System.out.println("Black wins!");
		}
	}

	public static int check(char[][] map, char c){
		int count = 0, i=0,j=0;
		//horizontally
		for(;i<map.length;i++){//vertically
			for(;j<map[i].length-2;j++){//horzontally
				if(map[i][j] == c && map[i][j+1] == c && map[i][j+2] == c){
					count++;
				}
			}
		}
		System.out.println(count);
		//vertically
		for(;j<map[i].length;j++){
			for(;i<map.length-2;i++){
				if(map[i][j] == c && map[i+1][j] == c && map[i+2][j] == c){
					count++;
				}
			}
		}
		System.out.println(count);
		//top left to bottom right
		for(;i<map.length-2;i++){
			for(;j<map[i].length-2;j++){
				if(map[i][j] == c && map[i+1][j+1] == c && map[i+2][j+2] == c){
					count++;
				}
			}
		}
		System.out.println(count);
		//top right to bottom left  
		for(;i<map.length-2;i++){
			for(int w=map[0].length-1;j>=2;j--){
				if(map[i][w] == c && map[i+1][w-1] == c && map[i+2][w-2] == c){
					count++;
				}
			}
		}
		System.out.println(count);
		return count;
	}
	
	public static int check1(char[][] map, char c){
		int count = 0;
		//horizontally
		for(int i=0;i<map.length;i++){//vertically
			for(int j=0;j<map[0].length-2;j++){//horzontally
				if(map[i][j] == c && map[i][j+1] == c && map[i][j+2] == c){
					count++;
				}
			}
		}
		System.out.println(count);
		//vertically
		for(int j=0;j<map[0].length;j++){
			for(int i=0;i<map.length-2;i++){
				if(map[i][j] == c && map[i+1][j] == c && map[i+2][j] == c){
					count++;
				}
			}
		}
		System.out.println(count);
		//top left to bottom right
		for(int i=0;i<map.length-2;i++){
			for(int j=0;j<map[0].length-2;j++){
				if(map[i][j] == c && map[i+1][j+1] == c && map[i+2][j+2] == c){
					count++;
				}
			}
		}
		System.out.println(count);
		//top right to bottom left  
		for(int i=0;i<map.length-2;i++){
			for(int j=map[0].length-1;j>=2;j--){
				if(map[i][j] == c && map[i+1][j-1] == c && map[i+2][j-2] == c){
					count++;
				}
			}
		}
		System.out.println(count);
		return count;
	}
}