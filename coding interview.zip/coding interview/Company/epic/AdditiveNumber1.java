/**
 * 
 */
package epic;

import java.util.ArrayList;

/**
 * @author Tiannan
 *Additive numbers are defined to be a positive integer whose digits form an
additive sequence. E.g. 11235 (1+1=2, 1+2=3, 2+3=5). What makes it . 
difficult is that 12,122,436 is also one (12+12=24, 12+24=36). Given a range
of integers, find all the additive numbers in that range. 
 */
public class AdditiveNumber1 {
   
    private static boolean isAdditiveNumber(final int number){
    	 if(number < 100){
             return false;
             }
    	 
    	final int length = (int)(Math.log10(number) + 1);
        for(int splitLength = 1; splitLength <= (length / 2); splitLength++){
            if(isAdditive(intToIntegerArray(number, splitLength))){
                return true;
            }
        }
        return false;
    }
    private static boolean isAdditive(ArrayList<Integer> numberList){
        if(numberList == null || numberList.size() < 3){
            return false;
        }
        for(int index = 0; index < numberList.size() - 2; index++){
            final int a = numberList.get(index);
            final int b = numberList.get(index + 1);
            final int c = numberList.get(index + 2);

            if(a + b != c){
                return false;
            }
        }
        return true;
    }
    private static ArrayList<Integer> intToIntegerArray(final int numberToConvert, final int digitNumInEachElement){
        if(numberToConvert < 100){
            return null;
        }
        if(digitNumInEachElement <= 0){
            return null;
        }else{
            final int length = (int)(Math.log10(numberToConvert) + 1);
            ArrayList<Integer> resultList = null;
            if(length % digitNumInEachElement == 1){
                final int lastDigit = numberToConvert % 10;
                resultList = splitHelper(numberToConvert / 10, digitNumInEachElement);
                final int lastIndex = resultList.size() - 1;
                resultList.set(lastIndex, resultList.get(lastIndex) * 10 + lastDigit);
            }else if(length % digitNumInEachElement == 0){
                resultList = splitHelper(numberToConvert, digitNumInEachElement); 
            }
            return matchLength(digitNumInEachElement, resultList) ? resultList : null;
        }
    }
    private static ArrayList<Integer> splitHelper(final int numberToConvert, final int digitNumInEachElement){
        final int divider = (int)Math.pow(10, digitNumInEachElement);
        int numToProcess = numberToConvert;
        ArrayList<Integer> resultList = new ArrayList<Integer>();
        while(numToProcess != 0){
            resultList.add(0, numToProcess % divider);
            numToProcess /= divider;
        }
        return resultList;
    }
    private static boolean matchLength(final int requiredLen, ArrayList<Integer> listToCheck){
        for(int element : listToCheck){
            if(element == 0){
                continue;
            }else{
                if(element < (int) Math.pow(10, requiredLen - 1)){
                    return false;
                }
            }
        }
        return true;
    }
    
    public static boolean isAdditiveNumber(String number)
    {
            for(int i=1;i<number.length();i++)
            {
                    
                    for(int j=i+1;j<number.length();j++)
                    {
                            int part1 = Integer.parseInt(number.substring(0,i));
                            int part2 = Integer.parseInt(number.substring(i,j));
                            int index= j;
                            int rest  = Integer.parseInt(number.substring(j,number.length()));
                            while(part1+part2<=rest)
                            {
                                    int part3 = part1+part2;
                                    String str = (new Integer(part3)).toString();
                                    int length = str.length();
                                    if(index + length > number.length())
                                    {
                                            break;
                                    }
                                    if(number.substring(index,index+length).equals(str))
                                    {
                                            index=length+index;
                                            if(index==number.length())
                                            {
                                                    return true;
                                            }
                                            part1 = part2;
                                            part2 = part3;
                                            rest = Integer.parseInt(number.substring(index,number.length()));
                                    }
                                    else
                                    {
                                            break;
                                    }
                            }
                    }
            }
            return false;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Math.pow(2.0, 5.0));
        System.out.println(isAdditiveNumber("112112224"));
        System.out.println(isAdditiveNumber(11235));
        System.out.println(isAdditiveNumber(366096156));
        System.out.println(isAdditiveNumber("366096156"));
        System.out.println("ab".substring(0,1));
	}

}
