/**
 * 
 */
package epic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * @author Tiannan
 *write a prog/method to convert number to character (as in old mobile phone). 
e.g. 2 entered 1 = A 
2 entered 2 = B 
2 entered 3 = C 
# = space 
22#22 = B B etc
 */
public class ConvertNumToChar {
	public static void convert (String s){
		HashMap<Character, List<Character>> numPad = new HashMap<Character, List<Character>>();

        numPad.put('1', new ArrayList<Character>() );
        numPad.put('2', Arrays.asList( 'A', 'B', 'C' ) );
        numPad.put('3', Arrays.asList( 'D', 'E', 'F' ) );
        numPad.put('4', Arrays.asList( 'G', 'H', 'I' ) );
        numPad.put('5', Arrays.asList( 'J', 'K', 'L' ) );
        numPad.put('6', Arrays.asList( 'M', 'N', 'O' ) );
        numPad.put('7', Arrays.asList( 'P', 'Q', 'R', 'S' ) );
        numPad.put('8', Arrays.asList( 'T', 'U', 'V' ) );
        numPad.put('9', Arrays.asList( 'W','X', 'Y', 'Z' ) );
        numPad.put('0', new ArrayList<Character>() );
/*use hashmap map num with chars
 *use string .split by # generate a array of string tokens 
 *loop each token 
 * */
       
        String inp = s; //"#666#666#";//9999#666#666
        
        String[] tokens = inp.split( "#" );

        for( String tok : tokens ){
            Character key = null;
            int index = 0;
            if( tok.length() >= 1 ) {
                key = tok.charAt(0);
                index = tok.length() - 1;
                System.out.print( numPad.get( key ).get( index ) );
            }
            System.out.print( " " );
        }
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a ="9999#666#666";
		convert (a);
		
	}

}
