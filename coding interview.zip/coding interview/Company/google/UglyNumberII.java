/**
 * 
 */
package google;

import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Queue;

/**��Ŀ��

Write a program to find the n-th ugly number.

Ugly numbers are positive numbers whose prime factors only include 2, 3, 5. 
For example, 1, 2, 3, 4, 5, 6, 8, 9, 10, 12 is the sequence of the first 10 ugly numbers.

Note that 1 is typically treated as an ugly number.

��⣺
�����

1 * 2�� 2* 2�� 3* 2�� .....

1* 3�� 2* 3�� 3*3��......

1* 5�� 2 * 5�� 3 * 5�� .......

����ugly number��������ugly number * 2, *3, *5�õ����������������У���һ��ugly numberΪ�������������е�ǰ��С��Ԫ�ء������ظ�Ԫ��ʱ��Ҫ�ƶ����ָ�롣
 * @author K25553
 *
 */
public class UglyNumberII {
	
	 public long kthPrimeNumber(int n) {        
	        Queue<Long> Q = new PriorityQueue<Long>();
	        HashMap<Long, Boolean> inQ = new HashMap<Long, Boolean>();
	        Long[] primes = new Long[3];
	        primes[0] = Long.valueOf(3);
	        primes[1] = Long.valueOf(5);
	        primes[2] = Long.valueOf(7);
	        for (int i = 0; i < 3; i++) {
	            Q.add(primes[i]);
	            inQ.put(primes[i], true);
	        }
	        Long number = Long.valueOf(0);
	        for (int i = 0; i < n; i++) {
	            number = Q.poll();
	            for (int j = 0; j < 3; j++) {
	                if (!inQ.containsKey(primes[j] * number)) {
	                    Q.add(number * primes[j]);
	                    inQ.put(number * primes[j], true);
	                }
	            }
	        }
	        return number;
	    }
	public int nthUglyNumber(int n) {
        int[] ugly = new int[n];
        ugly[0] = 1;
        int i2 = 0, i3 = 0, i5 = 0;
        for(int i = 1; i < n; i++) {
            int current = Math.min(ugly[i2] * 2, Math.min(ugly[i3] * 3, ugly[i5] * 5));
            ugly[i] = current;
            if(current == ugly[i2] * 2)
                i2++;
            if(current == ugly[i3] * 3)
                i3++;
            if(current == ugly[i5] * 5)
                i5++;
        }
        return ugly[n-1];
    }
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
