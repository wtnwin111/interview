/**
 * 
 */
package google;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**�������������ַ������������ĳ��ȴ��棬 
 * ���� abbreviation ����Ϊ a1breviation 
 * a2reviation 1bbreviation abbrevia4 ab3via4 abbreviation 11n 12�ȣ�
 * �ʣ�1��һ���ж�������д��2�����������Щ��д
 * @author K25553
 *
 */
public class WordAbbreviation {
	
	public Set<String> generate(String word) {
		  int n = word.length();
		  Set<String> res = new HashSet<>();

		  for (int i = 0; i < n; i++) {
		    for (int len = 0; len <= n - i; len++) {
		      String a = word.substring(0, i);
		      String b = len > 0 ? String.valueOf(len) : "";
		      String c = word.substring(i + len);

		      res.add(a + b + c);

		      if (c.length() >= 2) {
		        Set<String> rest = generate(c.substring(1));

		        for (String d : rest)
		          res.add(a + b + c.substring(0, 1) + d);
		      }
		    }
		  }

		  return res;
		}
	public List<String> abb (String s){
		ArrayList<String> res =new ArrayList<String>();
		if ( s.length()==0 || s==null){
			return res;
		}
		for(int i=0; i<s.length();i++){
			for (int j=0; j<=i;j++ ){
				res.add(s.substring(0, j)+String.valueOf(i-j+1)+s.substring(i, s.length()));
			}
		}
		return res;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
