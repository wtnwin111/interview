/**
 * 
 */
package google;

import java.util.HashMap;
import java.util.Stack;

/**
 * ��Ŀ�Ǹ�һ��string "( + 1 2 ( * 3 4 ) )" ����15
����123����123���� ����12
��+123(*123)) ����˼�� 1 + 2 + 3 + (1 * 2 * 3)
 * @author K25553
 *
 */
public class ParseReg {
	public static int cal(String input){
		int countLeft = 0;
		int countRight = 0;
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		int prevLeft = 0;
		for(int i = 0; i < input.length(); i++){
			if(input.charAt(i) == '('){

				if(i > prevLeft){
					String exp = input.substring(prevLeft+1, i);
					map.put(countLeft, exp);
				} 
				countLeft++;
				prevLeft = i;

			} else if(input.charAt(i) == ')'){
				if(countRight == 0){
					String exp = input.substring(prevLeft + 1, i);
					map.put(countLeft, exp);
					countRight++;
				}

			}

		}
		return _cal(map, countLeft);
	}

	private static int _cal(HashMap<Integer, String> map, int max){
		Stack<Integer> stack = new Stack<Integer>();
		while(max >= 1){
			String exp = map.get(max);
			if(!stack.isEmpty()){
				stack.push(eval(exp, stack.pop()));

			} else{
				stack.push(eval(exp, 0));
			}
			max--;
		}
		return stack.pop();
	}

	private static int eval(String exp, int d){
		char op = exp.charAt(0);

		int res = 0;
		if(op == '+'){
			for(int i = 1; i < exp.length(); i++){
				res += exp.charAt(i) - '0';
			}
			return res + d;

		}else{
			res = 1;
			for(int i = 1; i < exp.length(); i++){
				res *= (exp.charAt(i) - '0');


			}
			if(d != 0) res *= d;
			return res;
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
