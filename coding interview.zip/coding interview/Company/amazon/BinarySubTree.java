/**
 * 
 */
package amazon;

import tree.TreeNode;


/**
 * Given a binary tree, find the mini path sum from root to the leave. 





For example: 

Given the below binary tree, 

      1 

    /  \ 

   2      3 
  /  \    /  \
  4   5  6    7
        /  \ 
        8  9
 
Return 7.
 * @author Tiannan
 *
 */
public class BinarySubTree {
	 

	static boolean isSubTree(TreeNode t1, TreeNode t2) {
	    if(t2 == null ) {
	         return false;
	    }
	     if(t1 == null) {
	         return true;
	    }
	   if(isExactMatch(t1, t2)){
		   return true;
	   }
	   return isSubTree(t1, t2.left)||isSubTree(t1, t2.right);
	}
	
	static boolean isExactMatch(TreeNode t1,TreeNode t2) {
	     if(t1==null&&t2==null) return true;
	       
	     
	     if (t1 == null|| t2 == null) return false;
	     
	
	           
	    	 return (t1.val==t2.val&& isSubTree(t1.left, t2.left)&&isSubTree(t1.right, t2.right));
	     
	}
//	public static boolean isSubTree(TreeNode root,TreeNode root2){
//		
//		 if(root==null) return true;
//		 if(root2==null) return false;
//	
//			if(isIdentical(root,root2)) return true;
//			else {
//				return isIdentical(root,root2.left)||isIdentical(root,root2.right);
//			}
//		
//		  
//		
//	}
//	public static boolean isIdentical(TreeNode root,TreeNode root2){
//		
//		if(root==null&&root2==null) return true;
//		if(root==null||root2==null) return false;
//		
//		if(root.val==root2.val) {
//			return isSubTree(root.left,root2.left)&&isSubTree(root.right,root2.right);
//		}
//		else return false;
//		
//	}
//	  
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeNode root = new TreeNode(1);
        root.left = new TreeNode (2);
        root.right = new TreeNode (3);
        root.left.left = new TreeNode (4);
        root.left.right = new TreeNode (5);
        root.right.left = new TreeNode (6);
        root.right.right = new TreeNode (7);
        root.right.left.left = new TreeNode (8);
        root.right.left.right = new TreeNode (9);
        BinarySubTree i = new BinarySubTree();
        
       TreeNode root1=new TreeNode(10);
		root.left=new TreeNode(4);
		root.right=new TreeNode(6);
		root.left.right=new TreeNode(30);
		
		TreeNode root2=new TreeNode(10);
		root.left=new TreeNode(4);
		root.right=new TreeNode(6);
		root.left.right=new TreeNode(30);root.left.left=new TreeNode(30);
		
		
		TreeNode root22=new TreeNode(26);
		root22.left=new TreeNode(10);
		root22.left.left=new TreeNode(4);
		root22.left.right=new TreeNode(6);
		root22.left.left.right=new TreeNode(30);
		
//		root2.right=new TreeNode(6);
//		root2.right=new TreeNode(3);
//		root2.right.right=new TreeNode(3);
		
		System.out.println(isSubTree(root1,root22));
		//System.out.println(isIdentical(root,root2));
	}

}
