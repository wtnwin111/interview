/**
 * 
 */
package amazon;

import list.ListNode;



/**
 * @author Tiannan
 *
 */
public class InsertinSortedList {
	/**
	  * Several Cases:
	 
	  * 1st, when linked list is empty; 
	 
	  * 2nd, when new element is either minimum or maximum; 
	 
	  * 3rd, when new element is in between two sorted elements. 
	 
	  * 
	  * 
	  * Since this list is like a circle, we don't necessary to have the smallest
	  * element as the head, but it's definitely sorted.
	  * */
	 public static void insert(ListNode head,int x) {
	  // 1st Case;
	  if (head == null) {
	   head = new ListNode(x);
	   head.next = head;
	   return;
	  }else if(head.next==head){
		  head.next=new ListNode(x);
	  }
	  
	  ListNode cur= head.next;
	  ListNode pre= null;
	  while(cur!= head){
		  pre=cur;
		  cur=cur.next;
		  if(pre.val>=cur.val&&(x<=cur.val||x>=pre.val)){
			  break;
		  }
		  if(pre.val<=x&&cur.val>=x){
			  break;
			 
		  }
		  
	  }
	  ListNode p = head;
	  ListNode prev = null;

	  do {
	   prev = p;
	   p = p.next;
	   // 2nd Case;
	   if (prev.val >= p.val && (x <= p.val || x >= prev.val))
	    break;
	   // 3rd Case;
	   if (prev.val <= x && p.val >= x)
	    break;
	  } while (p != head);
	  ListNode tmp = new ListNode(x);
	  prev.next = tmp;
	  tmp.next = p;
	 }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListNode head = new ListNode(1);
		ListNode dummy = head;

		for(int i=2;i<10;i++){
			dummy.next= new ListNode(i);
			dummy=dummy.next;
			System.out.print(dummy.val+"->");
		}
		dummy.next = head;
		insert(head,0);insert(head,10);insert(head,15);insert(head,14);
		for(int i=2;i<20;i++){
			System.out.print(dummy.val+"->");
			dummy=dummy.next;
			
		}
		
		dummy = head;
	}

}
