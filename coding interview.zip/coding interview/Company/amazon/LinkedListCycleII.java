/**
 * 
 */
package amazon;

/**
 * ����һ���������ж����Ƿ��л���

���� 

���� -21->10->4->5, tail connects to node index 1������ true

��ս 

��Ҫʹ�ö���Ŀռ�

 * @author Tiannan
 *loop if fast != slow
 *if fast.next or fast==null return false 
 *once fast == slow return true
 */
public class LinkedListCycleII {
	public class ListNode {
		      int val;
		      ListNode next;
		      ListNode(int val) {
		          this.val = val;
		        this.next = null;
		     }}
	 public ListNode detectCycle(ListNode head) {
	        if (head == null || head.next==null) {
	            return null;
	        }

	        ListNode fast, slow;
	        fast = head.next;
	        slow = head;
	        while (fast != slow) {
	            if(fast==null || fast.next==null)
	                return null;
	            fast = fast.next.next;
	            slow = slow.next;
	        } 
	        
	        while (head != slow.next) {
	            head = head.next;
	            slow = slow.next;
	        }
	        return head;
	    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
