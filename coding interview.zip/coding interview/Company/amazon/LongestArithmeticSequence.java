/**
 * 
 */
package amazon;

/**
 * Give array, return the number of possible arithmetic sequence (�Ȳ�����)��
{-1,1,3,3,3,2,1,0} return 5 {-1,1,3,7,11,15,19,20,21,22} 6
 * @author Tiannan
 *
 */
public class LongestArithmeticSequence {
	/*dp:
	 * dp [array len]= max{}
	 * 
	 * */
	
	int longest_arithmetic_progression(int a[], int n){

		   int i,j,k;

		   int Table[][]= new int [n][n];
		   int longest_ap = 2;

		   for(i=0;i<n; i++)
		       Table[i][n-1] =2;

		   for(j= n-2; j>=1; j-- ){
		       i = j-1;
		       k = j+1;

		       while(i>=0 && k<n){
		           if(2* a[j] > a[i] + a[k]){
		                k++; // Table[j][k]is already filled 
		           }
		           else if (2* a[j] < a[i] + a[k]){
		             /*Table[i][j] needs to be filled before we move up */
		              Table[i ][j] =2; 
		              i--;
		           }
		           else{
		              Table[i][j] = Table[j][k] +1;
		              longest_ap = Math.max(longest_ap, Table[i][j]);
		              i--;
		              k++;
		           }
		        }
		        while(i>=0){
		          Table[i][j] =2; 
		          i--;
		        }  
		    }
		    return longest_ap;
		}
	public static int lenghtOfLongestAP(int set[], int n)
	{
	    if (n <= 2)  return n;
	 
	    // Create a table and initialize all values as 2. The value of
	    // L[i][j] stores LLAP with set[i] and set[j] as first two
	    // elements of AP. Only valid entries are the entries where j>i
	    int[][] L= new int [n][n];
	    int llap = 2;  // Initialize the result
	 
	    // Fill entries in last column as 2. There will always be
	    // two elements in AP with last number of set as second
	    // element in AP
	    for (int i = 0; i < n; i++)
	        L[i][n-1] = 2;
	 
	    // Consider every element as second element of AP
	    for (int j=n-2; j>=1; j--)
	    {
	        // Search for i and k for j
	        int i = j-1, k = j+1;
	        while (i >= 0 && k <= n-1)
	        {
	           if (set[i] + set[k] < 2*set[j])
	               k++;
	 
	           // Before changing i, set L[i][j] as 2
	           else if (set[i] + set[k] > 2*set[j])
	           {   L[i][j] = 2; i--;   }
	 
	           else
	           {
	               // Found i and k for j, LLAP with i and j as first two
	               // elements is equal to LLAP with j and k as first two
	               // elements plus 1. L[j][k] must have been filled
	               // before as we run the loop from right side
	               L[i][j] = L[j][k] + 1;
	 
	               // Update overall LLAP, if needed
	               llap = Math.max(llap, L[i][j]);
	 
	               // Change i and k to fill more L[i][j] values for
	               // current j
	               i--; k++;
	           }
	        }
	 
	        // If the loop was stopped due to k becoming more than
	        // n-1, set the remaining entties in column j as 2
	        while (i >= 0)
	        {
	            L[i][j] = 2;
	            i--;
	        }
	    }
	    return llap;
	}
	public static int GetTheLongestContinueArithmeticSequence(int[] input)
	{
		if (input == null) return 0;	
		if(input.length == 1) return 1;
		int Steps = 0;
		int Maxlen = 2;
		int currentLen = 2;
	
		for (int i = input.length-1; i >0; i--)
		{
			int value = input[i] - input[i - 1];
			if( value != Steps)
			{
				Steps = value;
				currentLen = 2;
				
			}
			else{
				currentLen++;
			}
			if (currentLen > Maxlen)
			{
				Maxlen = currentLen;
			
			}
		}
		
		return Maxlen;
	}
	
	public static int getLongestArithmeticSeq(int[] array) {
		if (array == null) return 0;	
		if(array.length == 1) return 1;
		int difference = array[1] - array[0];		// common difference of arithmetic sequence
		int longestLength = Integer.MIN_VALUE;	// stores the longest length sequence found till now
		int currentLength = 2;		// stores length of current arithmetic sequence
		for(int iii = 1; iii < array.length - 1; iii++) {
			int currentDifference = array[iii + 1] - array[iii];
			if (currentDifference == difference) {		// check if these elements are part of the sequence
				currentLength++;		// if they are, increase currentLenght
			} else {			// otherwise set currentLength to 1, and common difference to new difference
				currentLength = 2;
				difference = currentDifference;
			}
			longestLength = Math.max(longestLength, currentLength);		// store the maximum length
		}
		return longestLength;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(GetTheLongestContinueArithmeticSequence(new int[] {-1,0,1,2,3,3,3,2,1,0}));
		System.out.println(GetTheLongestContinueArithmeticSequence(new int[] {0}));
		System.out.println(getLongestArithmeticSeq(new int[] {-1,0,1,2,3,3,3,2,1,0}));
		System.out.println(getLongestArithmeticSeq(new int[] {0}));
		System.out.println(lenghtOfLongestAP(new int[] {-1,0,1,2,3,3,3,2,1,0},10));
		System.out.println(lenghtOfLongestAP(new int[] {0},1));
		System.out.println(lenghtOfLongestAP(new int[] {-1,1,3,7,11,15,19,20,21,22},10));
	}

}
