/**
 * 
 */
package amazon.onsite;

/**
 * @author Tiannan
 *
 */
public class ReverseString {
	public static String reverse(String s){
		if(s.isEmpty()){
			return s;
		}
		return reverse(s.substring(1))+s.charAt(0);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print(reverse("Hello World"));

	}

}
