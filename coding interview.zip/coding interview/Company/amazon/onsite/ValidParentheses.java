/**
 * 
 */
package amazon.onsite;

import java.io.Console;
import java.util.Scanner;
import java.util.Stack;

/**
 * @author Tiannan
 *
 */
public class ValidParentheses {
	public static boolean isValid(String s) {
		Stack<Character> stack = new Stack<Character>();
		for (Character c : s.toCharArray()) {
			if ("({[".contains(String.valueOf(c))) {
				stack.push(c);
			} 
			
			if ((!stack.isEmpty()) && is_valid(stack.peek(), c)) {
	
				stack.pop();

			}
			else if (stack.isEmpty() && ")}]".contains(String.valueOf(c))) {
				
				return false;

			}
		}
		
	return stack.isEmpty();
}

public static boolean is_valid(char c1, char c2) {
	return (c1 == '(' && c2 == ')') || (c1 == '{' && c2 == '}')
			|| (c1 == '[' && c2 == ']');
}
/**
 * @param args
 */
public static void main(String[] args) {
	// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	String s = sc.nextLine();
	System.out.println( isValid( s));
}

}
