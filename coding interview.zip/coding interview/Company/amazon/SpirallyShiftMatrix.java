/**
 * 
 */
package amazon;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * 题1:二维square数组spirally shift一位，顺时针。如果输入的不是square数组，输出error，否则输出处理后的二维数组。
 输入：
2 ／／接下来的输入行数
1 2 ／／ 每个元素之间以space隔开 鏉ユ簮涓€浜�.涓夊垎鍦拌鍧�. 
3 4 ／／ 同上. visit 1point3acres.com for more.
输出：. 1point3acres.com/bbs
 3 1
 4 2

输入：. 鐗涗汉浜戦泦,涓€浜╀笁鍒嗗湴
3
 1 2 3 
 4 5 6
 7 8 9
. 鐣欏鐢宠璁哄潧-涓€浜╀笁鍒嗗湴
 输出：
4 1 2
 7 5 3 
 8 9 6
. 鍥磋鎴戜滑@1point 3 acres
输入：. Waral 鍗氬鏈夋洿澶氭枃绔�,
2
 1 2 3
 4 5 6
输出：. 涓€浜�-涓夊垎-鍦帮紝鐙鍙戝竷
ERROR

 * @author Tiannan
 *
 */
public class SpirallyShiftMatrix {
	public static int[][] shift(int[][] matrix) {
		int tmp = matrix[1][0];
		int x = 0;
		int y = 0;
		int m = matrix.length;
		int n = matrix[0].length;

		while(m > 0 && n > 0) {
			for(int i = 0 ; i < n - 1; i++) {
				int t = tmp;
				tmp = matrix[x][y];
				matrix[x][y] = t;
				y++;
			}
			for(int i = 0 ; i < m - 1; i++) {
				int t = tmp;
				tmp = matrix[x][y];
				matrix[x][y] = t;
				x++;
			}
			for(int i = 0 ; i < n - 1; i++) {
				int t = tmp;
				tmp = matrix[x][y];
				matrix[x][y] = t;
				y--;
			}
			for(int i = 0 ; i < m - 1; i++) {
				int t = tmp;
				tmp = matrix[x][y];
				matrix[x][y] = t;
				x--;
			}
			x++;
			y++;
			m-=2;
			n-=2;
		}
		return matrix;
	}

	public static void spiral(char matrix [][] ){
		//easy, do not make silly mistake
		int row = matrix.length;
		int col = matrix[0].length;
		int x = 0, y=col;
		StringBuffer sb = new StringBuffer();
		while(true){
			for(int i=0;i<col;i++){
				sb.append(matrix[x][--y]);
			}
			row--;
			if(row==0) break;
			for(int i=0;i<row;i++){
				sb.append(matrix[++x][y]);
			}
			col--;
			if(col==0) break;
			for(int i=0;i<col;i++){
				sb.append(matrix[x][++y]);
			}
			row--;
			if(row==0)break;
			for(int i=0;i<row;i++){
				sb.append(matrix[--x][y]);
			}
			col--;
			if(col==0) break;
		}
		System.out.println(sb.toString());
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		int size = input.nextInt();
		  System.out.println(size);
		ArrayList<Integer> temp= new ArrayList<Integer>();
		
		while(input.hasNextInt()) {
			int a = input.nextInt();
			temp.add(a);
			  System.out.println(a);
		}
		input.close();
		
		if(temp.size()!=(size*size)){
			System.out.println("ERROR");
		}else{
			int[][] matrix = new int[size][size];
			int x =0;
			for ( int i = 0 ; i < size ; i++ )
			{	
				for ( int j = 0 ; j < size ; j++ )
				{
					matrix[i][j]=temp.get(x++);
					 System.out.print(matrix[i][j]);
				}System.out.println();
			}	
		
		int [][]c= shift(matrix);
		for(int i=0;i<c.length;i++){
			for(int j=0;j<c[0].length;j++){
				System.out.print(c[i][j]+" ");
			}
			System.out.println();
		}
		}
		
//		for(int i=0;i<n;i++){
//			for(int j=0;j<n;j++){
//				System.out.print(matrix[i][j]+" ");
//			}
//			System.out.println();
//		}
//
//		// TODO Auto-generated method stub
//		int a[][]= new int[][]{
//				{1,2,3,4},
//				{14,15,16,17},
//				{13,20,19,18},
//				{12,11,10,9}
//		};
//		int b[][]= new int[][]{
//				{1,1,0,1,0},
//				{1,1,1,1,0},
//				{0,1,0,1,0},
//				{0,0,1,0,0}
//		};
//		int [][]c= shift(a);
//		for(int i=0;i<c.length;i++){
//			for(int j=0;j<c[0].length;j++){
//				System.out.print(a[i][j]+" ");
//			}
//			System.out.println();
//		}
//
//
//		for(int i=0;i<c.length;i++){
//			for(int j=0;j<c[0].length;j++){
//				System.out.print(c[i][j]+",");
//			}
//			System.out.println();
//		}
	}

}

