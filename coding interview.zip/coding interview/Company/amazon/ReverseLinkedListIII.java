/**
 * 
 */
package amazon;

import list.ListNode;


/**
 * ��һ��LinkedList, �Ѻ���reverse 1,2,3,4,5,6 -> 1,2,3,6,5,4.

Challenge 

Reverse it in-place and in one-pass

 * @author Tiannan
 *use dummy node to record the head
 *use head to 
 */
public class ReverseLinkedListIII {
	
	 
	public static void reverse(ListNode head1) {
		 ListNode head=head1;
		 if (head== null || head.next == null) {
	            return;
	        }

	        ListNode fast, slow;
	        fast = head.next;
	        slow = head;
	        while (fast != null && fast.next != null) {  
	            fast = fast.next.next;
	            slow = slow.next;
	        } 
	        ListNode pre=null; 
	        ListNode cur= slow.next;
	     	while(cur!=null){
	     		ListNode next= cur.next;
	     		cur.next=pre;
	     		pre=cur;
	     		cur=next;
	     	}
	     	slow.next=pre;
	 }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListNode head = new ListNode(1);
		ListNode dummy = head;

		for(int i=2;i<10;i++){
			dummy.next= new ListNode(i);
			dummy=dummy.next;
			
		}
		dummy = head;
		do{
			System.out.print(dummy.val+"->");
			dummy=dummy.next;
		} while(dummy !=null);
		
		dummy = head;
		reverse( dummy);
		do{
			System.out.print(dummy.val+"->");
			dummy=dummy.next;
		} while(dummy !=null);
	}

}
