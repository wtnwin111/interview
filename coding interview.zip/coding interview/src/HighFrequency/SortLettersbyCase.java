/**
 * 
 */
package HighFrequency;

import java.util.Arrays;

/**
 * Given a string which contains only letters. Sort it by lower case first and upper case second.

Example
For "abAcD", a reasonable answer is "acbAD"
 * @author Tiannan
 *
 */
public class SortLettersbyCase {
	/** 
     *@param chars: The letter array you should sort by Case
     *@return: void
     */
    public static void sortLetters(char[] chars) {
        //write your code here
    	if (chars.length<=1||chars==null)
    		return;
    	
    	int start= 0;
    	int end=chars.length-1;
    	while (end>start){
    		while(chars[start]>='a'&&chars[start]<='z'&&end>start) start++;
    		while(chars[end]>='A'&&chars[end]<='Z'&&end>start) end--;
    		if(start<end){
    			
    		
    		char temp= chars[start];
    		chars[start]=chars[end];
    		chars[end]=temp;
    		System.out.println(chars[start]+"   "+chars[end]);
    		start++;
    		end--;
    		
    		}
    	}
    	System.out.println(chars[start]+"   "+chars[end]);
    	System.out.println(start+"   "+end);
    	Arrays.sort(chars, 0,end);
    	Arrays.sort(chars, end, chars.length);
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char chars[]={
				'b','a','A','c','D'
		};
		sortLetters(chars) ;
		for(char a: chars){
			System.out.println(a);
		}
		System.out.println();
	}

}
