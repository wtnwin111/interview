/**
 * 
 */
package HighFrequency;

/**
 * Given an array of integers, the majority number is the number that occurs more than half of the size of the array. Find it.

Example 

For [1, 1, 1, 1, 2, 2, 2], return 1

Challenge 

O(n) time and O(1) space

 * @author Tiannan
 *findCandidate(a[], size)
1.  Initialize index and count of majority element
     maj_index = 0, count = 1
2.  Loop for i = 1 to size �C 1
    (a)If a[maj_index] == a[i]
        count++
    (b)Else
        count--;
    (c)If count == 0
        maj_index = i;
        count = 1
3.  Return a[maj_index]

 */
public class MajorityNumber {
	public static int findCandidate(int []a){
		int count =1;
		int can= a[0];
		for (int i=1; i<a.length;i++){
			if (count==0){
				can=a[i];
				count=1;
			}else if (can!=a[i]){
				count--;
			}else{
				count++;
			}
		}
		return can;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[] = {2, 2, 3, 5, 2, 2, 6};
		int[] b = {2, 2, 2, 2, 3,3,3,3,3,5   };
		System.out.print(findCandidate(b));
	}

}
