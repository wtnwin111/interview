/**
 * 
 */
package HighFrequency;

import java.util.ArrayList;

/**
 * Given an array of integers, find two non-overlapping subarrays which have the largest sum.

The number in each subarray should be contiguous.

Return the largest sum.
 * @author Tiannan
 *  find two non-overlapping subarrays which have the largest sum.
 *  1 2 non overlapping subs: for position i subl is max sub from 0 to i of all subs, subr is max from len-1 to i+1 of all subs
 *  2 max of 2 subs is max(max, subl+subr) from 0 to le-1
 */
public class MaximumSubarrayII {
	  public int maxTwoSubArrays(ArrayList<Integer> nums) {
	        // write your code
	        int size = nums.size();
	        int[] left = new int[size];
	        int[] right = new int[size];
	        int sum = 0;
	        int minSum = 0;
	        int max = Integer.MIN_VALUE;
	        for(int i = 0; i < size; i++){
	            sum += nums.get(i);
	            max = Math.max(max, sum - minSum);
	            minSum = Math.min(sum, minSum);
	            left[i] = max;
	        }
	        sum = 0;
	        minSum = 0;
	        max = Integer.MIN_VALUE;
	        for(int i = size - 1; i >= 0; i--){
	            sum += nums.get(i);
	            max = Math.max(max, sum - minSum);
	            minSum = Math.min(sum, minSum);
	            right[i] = max;
	        }
	        max = Integer.MIN_VALUE;
	        for(int i = 0; i < size - 1; i++){
	            max = Math.max(max, left[i] + right[i + 1]);
	        }
	        return max;
	    }
	// sliding window:
	//if current ele is less than 0, sum =0, 
	public static int maxTwoSubArrays(int []nums) {
		int [ ] left = new int [nums.length];
		int [ ] right = new int [nums.length];
		left[0]=nums[0];
		right[nums.length-1]= nums[nums.length-1];
		for(int i=1;i<nums.length;i++){
			left[i]=Math.max(nums[i], left[i-1]+nums[i]);
			
		}
		for(int i=nums.length-2;i>=0;i--){
			right[i]=Math.max(nums[i], right[i+1]+nums[i]);
			
		}
		int lmax,rmax;
		int max= lmax=rmax=Integer.MIN_VALUE;
		int i=1;int j= nums.length-2;
		while(i<j){
			lmax=Math.max(left[i], left[i-1]);
			rmax=Math.max(right[j], right[j+1]);
			i++;j--;
		}
		return lmax+rmax;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(maxTwoSubArrays(new int []{1, 3, -1, 2, -1, 2}));
	
	}

}
