package thread;

public class DeadlockExample {
	String resource1 = "��Դ1";
	String resource2 = "��Դ2";
	Thread t1 = new Thread("�߳�1") {
		public void run() {
			while (true) {
				synchronized (resource1) {
					synchronized (resource2) {
						System.out.printf("�߳�1ӵ��[%s], ��Ҫ[%s]\n", resource1, resource2);
					}
				}
			}
		}
	};
	Thread t2 = new Thread("�߳�2") {
		public void run() {
			while (true) {
				synchronized (resource2) {
					System.out.printf("�߳�2ӵ��[%s], ��Ҫ[%s]\n", resource2, resource2);
					synchronized (resource1) {
						System.out.printf("�߳�2ӵ��[%s], ��Ҫ[%s]\n", resource2, resource1);
					}
				}
			}
		}
	};

	public static void main(String a[]) {
		DeadlockExample test = new DeadlockExample();
		test.t1.start();
		test.t2.start();
	}

}