/**
 *
 */
package dp.twoPoint;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Given a string s, find the length of the longest substring T that
 * contains at most k distinct characters.
 *
 * For example, Given s = "eceba", k = 3,
 *
 * T is "eceb" which its length is 4.
 *
 * Challenge
 *
 * O(n), n is the size of the string s.
 *
 * @author Tiannan
 *         analysis:update 2 pointers i to j to find the longest(update max):
 *         update j to the pointer while the set.size is just more than k
 *         then remove char i from the map, i++, until j to the end
 */
public class LongestSubstringwithAtMostKDistinctCharacters {
	public int lengthOfLongestSubstringKDistinct2(String s, int k) {
		// write your code here
		int maxLen = 0;

		// Key: letter; value: the number of occurrences.
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		int i, j = 0;
		char c;
		for (i = 0; i < s.length(); i++) {
			while (j < s.length()) {
				c = s.charAt(j);
				if (map.containsKey(c)) {
					map.put(c, map.get(c) + 1);
				} else {
					if (map.size() == k) {
						break;
					}
					map.put(c, 1);
				}
				j++;
			}

			maxLen = Math.max(maxLen, j - i);
			c = s.charAt(i);
			if (map.containsKey(c)) {
				int count = map.get(c);
				if (count > 1) {
					map.put(c, count - 1);
				} else {
					map.remove(c);
				}
			}
		}
		return maxLen;
	}

	/**
	 * @param s
	 *            : A string
	 * @return : The length of the longest substring
	 *         that contains at most k distinct characters.
	 */
	public int lengthOfLongestSubstringKDistinct(String s, int k) {
		// write your code here
		int slow = 0;
		int maxLen = 0;

		// Key: letter; value: the number of occurrences.
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		int fast;
		for (fast = 0; fast < s.length(); ++fast) {
			char c = s.charAt(fast);
			if (map.containsKey(c)) {
				map.put(c, map.get(c) + 1);
			} else {
				map.put(c, 1);
				while (map.size() > k) {
					char slowChar = s.charAt(slow++);
					int count = map.get(slowChar);
					if (count > 1) {
						map.put(slowChar, count - 1);
					} else {
						map.remove(slowChar);
					}
				}
			}

			maxLen = Math.max(maxLen, fast - slow + 1);
		}

		return maxLen;
	}

	/**
	 * @param s
	 *            : A string
	 * @return : The length of the longest substring
	 *         that contains at most k distinct characters.
	 */
	public static int lengthOfLongestSubstringKDistinct1(String s, int k) {
		if (s.length() < 2 || s == null) {
			return s.length();
		}
		// 2pointer
		int slow = 0, fast = 0, len = s.length();

		// cache to track unique characters, counter to trakc global maxlen,
		// distinc char count
		int[] chars = new int[256];
		Arrays.fill(chars, 0);
		int maxLen = 0;
		int discount = 0;

		for (; slow < len; slow++) {
			while (fast < len) {
				int index1 = s.charAt(fast);
				if (chars[index1] == 0) {
					chars[index1]++;
					discount++;
				} else {
					chars[index1]++;
				}
				if (discount == k) {
					break;
				}

				fast++;
			}
			maxLen = Math.max(maxLen, fast - slow + 1);
			int index = s.charAt(slow);
			chars[index]--;
			if (chars[index] == 0) {
				discount--;
			}
		}
		return maxLen;
	}

	/**
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(lengthOfLongestSubstringKDistinct1(
				"eqgkcwGFvjjmxutystqdfhuMblWbylgjxsxgnoh", 16));

	}

}
