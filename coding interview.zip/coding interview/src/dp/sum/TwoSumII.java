/**
 * 
 */
package dp.sum;

import java.util.Arrays;

/**
 * Given an array of integers, find how many pairs in 
 * the array such that their sum is bigger than a specific 
 * target number. 
 * Please return the number of pairs.
 * @author K25553
 *
 */
public class TwoSumII {
	 /**
     * @param nums: an array of integer
     * @param target: an integer
     * @return: an integer
     */
    public int twoSum2(int[] nums, int target) {
        Arrays.sort(nums);
        int l = 0, r= nums.length-1, ct=0;
        while( l< r){
        	if (nums[l]+nums[r]>target){
        		ct += r-l;
        		r--;
        	}
//        	else if(nums[l]+nums[r]==target){
//        		ct += r-l-1;
//        	}
        	else{
        		l++;
        	}
        }
        return ct;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
