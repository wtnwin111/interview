package dp;



import java.util.Arrays;
import java.util.Comparator;

public class BoxStacking {

	public static void main(String[] args) {
		Box[] A = new Box[4];
		A[0] = new Box(4,6,7);
		A[1] = new Box(1,2,3);
		A[2] = new Box(4,5,6);
		A[3] = new Box(10,12,32);
		int n = A.length;
		System.out.println(maxStackHeight(A, n));
	}	
	
	// Time Complexity: O(n^2) Auxiliary Space: O(n)
	public static int maxStackHeight(Box[] A, int n){
		/* Create an array of all rotations of given boxes
	      For example, for a box {1, 2, 3}, we consider three
	      instances{{1, 2, 3}, {2, 1, 3}, {3, 1, 2}} */
		Box[] rot = new Box[3*n];
		int index = 0;
		for(int i=0; i<n; i++){
			rot[index] = A[i];		// Copy the original box
			index++;
			
			rot[index] = new Box();		// First rotation of box
			rot[index].h = A[i].w;
			rot[index].d = Math.max(A[i].h, A[i].d);
			rot[index].w = Math.min(A[i].h, A[i].d);
			index++;
			
			rot[index] = new Box();		// Second rotation of box
			rot[index].h = A[i].d;
			rot[index].d = Math.max(A[i].h, A[i].w);
			rot[index].w = Math.min(A[i].h, A[i].w);
			index++;
		}
		
		n = 3*n;		// Now the number of boxes is 3n
		
		/* Sort the array ��rot[]�� in decreasing order, using library
	      function for quick sort */
		
		Arrays.sort(rot);
//		Arrays.sort(rot, new Comparator<Box>() {
//			@Override
//			public int compare(Box o1, Box o2) {		// ��������ݼ�����
//				return  (o1.d*o1.w)-(o2.d*o2.w);
//			}
//		});
		
		/* Initialize msh values for all indexes 
	      msh[i] �C> Maximum possible Stack Height with box i on top */
		int[] msh = new int[n];
		for(int i=0; i<n; i++){
			msh[i] = rot[i].h;
		}
		
		/* Compute optimized msh values in bottom up manner */
		for(int i=1; i<n; i++){
			for(int j=0; j<i; j++){
				if(rot[i].w<rot[j].w && rot[i].d<rot[j].d){
					msh[i] = Math.max(msh[i], msh[j]+rot[i].h);
				}
			}
		}
		
		/* Pick maximum of all msh values */
		int max = 0;
		for(int i=0; i<n; i++){
			max = Math.max(max, msh[i]);
		}
		return max;
	}

	public static class Box implements Comparable<Box>{
		int h, w, d;		// h �C> height, w �C> width, d �C> depth
		// for simplicity of solution, always keep w <= d
		public Box(){
		}
		public Box(int h_, int w_, int d_){
			h = h_;
			w = w_;
			d = d_;
		}
		@Override
		public int compareTo(Box o) {
			// TODO Auto-generated method stub
			return (o.w*o.d)-(this.d*this.w);
		}
		
	}
}

