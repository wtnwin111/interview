/**
 * 
 */
package dp;

import java.util.HashMap;
import java.util.HashSet;

/**Given an unsorted array of integers, find the length of the longest consecutive elements sequence.


Example
Given [100, 4, 200, 1, 3, 2],
The longest consecutive elements sequence is [1, 2, 3, 4]. Return its length: 4.
 * @author Tiannan
 *
 */
public class LongestConsecutiveSequence {
	// Sort & search: space O(1), time O(n logn)
    // HashMap: space O(n), time O(n)
    public int longestConsecutive(int[] num) {
        HashMap<Integer, Integer> hs = new HashMap<Integer, Integer>();
        for(int i: num){
            hs.put(i, 0);
        }
        int maxl = 1;
        for(int i: num){
            if (hs.get(i) == 1) continue;

            int tmp = i;
            int current_max = 1;
            while(hs.containsKey(tmp+1)){
                current_max ++;
                tmp ++;
                hs.put(tmp, 1);
            }

            tmp = i;
            while(hs.containsKey(tmp-1)){
                current_max ++;
                tmp --;
                hs.put(tmp, 1);
            }

            maxl = Math.max(current_max, maxl);
        }

        return maxl;
    }
    
    public int longestConsecutive1(int[] num) {
        if (num == null) {
            return 0;
        }
        
        HashSet<Integer> set = new HashSet<Integer>();
        for (int i: num) {
            set.add(i);
        }
        
        int max = 0;
        
        for (int i: num) {
            set.remove(i);
            int sum = 1;
            
            int tmp = i - 1;
            while (set.contains(tmp)) {
                // bug 1��forget to add the remove statement.
                set.remove(tmp);
                sum++;
                tmp--;
            }
            
            tmp = i + 1;
            while (set.contains(tmp)) {
                set.remove(tmp);
                sum++;
                tmp++;
            }
            
            max = Math.max(max, sum);
        }
        
        return max;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
