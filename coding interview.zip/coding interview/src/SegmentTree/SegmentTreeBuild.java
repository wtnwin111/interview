
package SegmentTree;



/**The structure of Segment Tree is a binary tree which each node has two attributes start and end denote an segment / interval.

start and end are both integers, they should be assigned in following rules:

The root's start and end is given by build method.
The left child of node A has start=A.left, end=(A.left + A.right) / 2.
The right child of node A has start=(A.left + A.right) / 2 + 1, end=A.right.
if start equals to end, there will be no children for this node.
Implement a build method with two parameters start and end, so that we can create a corresponding segment tree with every node has the correct start and end value, return the root of this segment tree.

Example
Given start=0, end=3. The segment tree will be:

               [0,  3]
             /        \
      [0,  1]           [2, 3]
      /     \           /     \
   [0, 0]  [1, 1]     [2, 2]  [3, 3]
Given start=1, end=6. The segment tree will be:

               [1,  6]
             /        \
      [1,  3]           [4,  6]
      /     \           /     \
   [1, 2]  [3,3]     [4, 5]   [6,6]
   /    \           /     \
[1,1]   [2,2]     [4,4]   [5,5]
Clarification
Segment Tree (a.k.a Interval Tree) is an advanced data structure which can support queries like:

See wiki: Segment Tree Interval Tree
 * @author Tiannan
 *
 */
/**
 * Definition of SegmentTreeNode:
 * public class SegmentTreeNode {
 *     public int start, end;
 *     public SegmentTreeNode left, right;
 *     public SegmentTreeNode(int start, int end) {
 *         this.start = start, this.end = end;
 *         this.left = this.right = null;
 *     }
 * }
 *
 * 
 For array [1, 4, 2, 3], the corresponding Segment Tree is:

                  [0, 3, max=4]
                 /             \
          [0,1,max=4]        [2,3,max=3]
          /         \        /         \
   [0,0,max=1] [1,1,max=4] [2,2,max=2], [3,3,max=3]
query(root, 1, 1), return 4

query(root, 1, 2), return 4

query(root, 2, 3), return 3

query(root, 0, 2), return 4
 *
 * 
 * 
 */
public class SegmentTreeBuild {
    /**
     *@param start, end: Denote an segment / interval
     *@return: The root of Segment Tree
     */
    public SegmentTreeNode build(int start, int end, int a[]) {
        // write your code here
    	if (start>end){
    		return null;
    	}
    	 
    	SegmentTreeNode root= new SegmentTreeNode(start, end);
    	if (start==end){
	    	root.count=1;
	    	root.sum=a[start];
	    	root.min=a[start];
	    	root.max=a[start];
	    }
    	if(start!=end){
    		int mid= (start+end)/2; 
    		root.left= build(start, mid, a);
    		root.right= build(mid+1, end, a);
    		root.max= Math.max(root.left.max, root.right.max); 
    	}
    	
    	return root;
    }
    /**
     *@param root, start, end: The root of segment tree and 
     *                         an segment / interval
     *@return: The maximum number in the interval [start, end]
     */
    public int query(SegmentTreeNode root, int start, int end) {
    	if(start==root.start&&end== root.end){
    		return root.max;
    	}
    	int mid= (root.start+ root.end)/2; 
    	int lmax=Integer.MAX_VALUE;
    	int rmax=Integer.MIN_VALUE;
    	//deal left scope 
    	if(start<=mid){
    		if (mid<end){
    			lmax=query(root.left, start, mid);
    		}else{
    			lmax= query(root.left, start, end);
    		}
    		
    	}
    	//deal right scope 
    	if(mid<end){
    		if (start<=mid ){
    			rmax=query(root.right, mid+1, end );
    		}
    		else{
    			rmax= query(root.right, start, end);
    		}
    		
    	}
    	//else is not in the scope so return 
    	return Math.max(lmax,rmax);
    }
    
    /**
     *@param root, index, value: The root of segment tree and 
     *@ change the node's value with [index, index] to the new given value
     *@return: void
     */
    public void modify(SegmentTreeNode root, int index, int value) {
    	//found updated scope, then update scope max = value
    	if(root.start==index&&root.end==index){
    		root.max=value;
    		return;
    	}
    	int mid= (root.start+root.end)/2;
    	//if index in the left scope
    	if(root.start<=index&&index<=mid){
    		modify(root.left, index, value);
    	}
    	//if index in the right scope
    	if(mid<index&&index<root.end){
    		modify(root.right,index, value);
    		
    	}
    	
    	root.max= Math.max(root.left.max, root.right.max);
    	
    }
    /**
     *@param root, start, end: The root of segment tree and 
     *                         an segment / interval
     *@return: The count number in the interval [start, end]
     */
    public int query2(SegmentTreeNode root, int start, int end) {
    	if (root.start==start&&root.end==end){
    		return root.sum;
    	}
    	int mid= (root.start+root.end)/2;
    	int lsum=0;int rsum=0;
    	//deal with left scope
    	if(start<=mid){
    		if(end<mid){
    			query(root.left, start, end);
    		}
    		else{
    			query(root.left, start, mid);
    		}
    	}
    	
    	if (mid<end){
    		if(start<=mid){
    			query(root.right, mid+1, end);
    		}else{
    			query(root.right, start, end);
    		}
    	}
    	return lsum+rsum;
    }
}
