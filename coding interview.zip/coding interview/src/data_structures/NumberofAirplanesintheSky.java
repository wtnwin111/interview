/**
 *
 */
package data_structures;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Given an interval list which are flying and landing time of the flight. How
 * many airplanes are on the sky at most?
 * For interval list
 *
 * [
 * [1,10],
 * [2,3],
 * [5,8],
 * [4,7]
 * ]
 * Return 3
 *
 * @author K25553
 *         scan line:
 */
public class NumberofAirplanesintheSky {
	public class Interval {
		int start, end;

		Interval(int start, int end) {
			this.start = start;
			this.end = end;
		}
	}

	static class Point {
		int time, status;

		Point(int time, int status) {
			this.time = time;
			this.status = status;
		}

		public static Comparator<Point> pointComparator = new Comparator<Point>() {

			@Override
			public int compare(Point o1, Point o2) {
				if (o1.time == o2.time) {
					// to aviod case like 12 23 34 the max is 1 not 2
					return o2.status - o1.status;
				}
				return o2.time - o1.time;
			}
		};
	}

	/**
	 * @param intervals
	 *            : An interval array
	 * @return: Count of airplanes are in the sky.
	 */
	public int countOfAirplanes(List<Interval> airplanes) {
		if (airplanes.size() == 0 || airplanes == null) {
			return 0;
		}
		Point allpoint[] = new Point[2 * (airplanes.size())];
		int i = 0;
		for (Interval a : airplanes) {
			allpoint[i] = new Point(a.start, 1);
			i++;
			allpoint[i] = new Point(a.end, 2);
			i++;
		}
		Arrays.sort(allpoint, Point.pointComparator);
		int ct = 0, max = 0;
		for (Point p : allpoint) {
			if (p.status == 1) {
				ct++;
			} else {
				ct--;
			}
			max = Math.max(max, ct);
		}
		return max;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
