/**
 *
 */
package sort;

/**
 * Given an unsorted array nums, reorder it such that
 *
 * nums[0] < nums[1] > nums[2] < nums[3]....
 * Example
 * Given nums = [1, 5, 1, 1, 6, 4], one possible answer is [1, 4, 1, 5, 1, 6].
 *
 * Given nums = [1, 3, 2, 2, 3, 1], one possible answer is [2, 3, 1, 3, 1, 2].
 *
 * @author K25553
 *         quick select median, compare median with each ele to insert into
 *         right position in a new empty array
 */
public class WiggleSortII {
	public static void wiggleSort(int[] nums) {
		int[] tem = new int[nums.length];
		for (int i = 0; i < nums.length; i++) {
			tem[i] = nums[i];
		}
		// partition based on median
		int mid = partition(tem, 0, nums.length - 1, nums.length / 2);
		int[] ans = new int[nums.length];
		for (int i = 0; i < nums.length; i++) {
			ans[i] = mid;
		}
		int l, r;
		if (nums.length % 2 == 0) {
			l = nums.length - 2;
			r = 1;
			for (int i = 0; i < nums.length; i++) {
				if (nums[i] < mid) {
					ans[l] = nums[i];
					l -= 2;
				} else if (nums[i] > mid) {
					ans[r] = nums[i];
					r += 2;
				}
			}
		} else {
			l = 0;
			r = nums.length - 2;
			for (int i = 0; i < nums.length; i++) {
				if (nums[i] < mid) {
					ans[l] = nums[i];
					l += 2;
				} else if (nums[i] > mid) {
					ans[r] = nums[i];
					r -= 2;
				}
			}
		}
		for (int i = 0; i < nums.length; i++) {
			nums[i] = ans[i];
		}
	}

	public static int partition(int[] nums, int l, int r, int rank) {
		int left = l, right = r;
		int now = nums[left];
		while (left < right) {
			while (left < right && nums[right] >= now) {
				right--;
			}
			nums[left] = nums[right];
			while (left < right && nums[left] <= now) {
				left++;
			}
			nums[right] = nums[left];
		}
		if (left - l == rank) {
			return now;
		} else if (left - l < rank) {
			return partition(nums, left + 1, r, rank - (left - l + 1));
		} else {
			return partition(nums, l, right - 1, rank);
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
