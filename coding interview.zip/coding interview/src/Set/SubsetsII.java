/**
 *
 */
package Set;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 * Given a list of numbers that may has duplicate numbers,
 * return all possible subsets
 *
 *
 * Example
 *
 * If S = [1,2,2], a solution is:
 * [
 * [2],
 * [1],
 * [1,2,2],
 * [2,2],
 * [1,2],
 * []
 * ]
 *
 * Note
 *
 * Each element in a subset must be in non-descending order.
 *
 * The ordering between two subsets is free.
 *
 * The solution set must not contain duplicate subsets.
 *
 * @author Tiannan
 *
 */
public class SubsetsII {
	/**
	 * @param S
	 *            : A set of numbers.
	 * @return: A list of lists. All valid subsets.
	 */

	/**
	 * @param S
	 *            : A set of numbers.
	 * @return: A list of lists. All valid subsets.
	 */
	public ArrayList<ArrayList<Integer>> subsetsWithDup(ArrayList<Integer> s) {
		ArrayList<ArrayList<Integer>> res = new ArrayList<ArrayList<Integer>>();
		if (s == null || s.size() == 0) {
			return res;
		}
		Collections.sort(s);
		dfs1(s, res, new ArrayList<Integer>(), 0);
		return res;
	}

	private void dfs1(ArrayList<Integer> dic,
			ArrayList<ArrayList<Integer>> res, ArrayList<Integer> temp, int pos) {
		res.add(new ArrayList<Integer>(temp));
		int start = pos;
		for (int i = pos; i < dic.size(); i++) {
			if (i != start && dic.get(i) == dic.get(i - 1)) {
				continue;
			}
			temp.add(dic.get(i));

			dfs1(dic, res, temp, i + 1);

			temp.remove(temp.size() - 1);
		}
	}

	public static ArrayList<ArrayList<Integer>> subsets(ArrayList<Integer> s) {
		Collections.sort(s);
		ArrayList<ArrayList<Integer>> res = new ArrayList<ArrayList<Integer>>();
		dfs(s, res, new ArrayList<Integer>(), 0);
		return res;
	}

	private static void dfs(ArrayList<Integer> list,
			ArrayList<ArrayList<Integer>> res, ArrayList<Integer> temp, int pos) {
		// TODO Auto-generated method stub

		res.add(new ArrayList<Integer>(temp));

		// dfs search to the leave
		// since each recursion to i=pos, so this will tranverse the duplicated
		// for once
		// like 1 12 122
		// then back tracking update by
		/*
		 * if(i!=pos&&list.get(i)==list.get(i-1)){
		 * continue;
		 * }
		 * on the same layer this will aviod duplicated
		 * like 12 no12 no13
		 */
		for (int i = pos; i < list.size(); i++) {
			if (i != pos && list.get(i) == list.get(i - 1)) {
				continue;
			}
			temp.add(list.get(i));
			dfs(list, res, temp, i + 1);
			temp.remove(temp.size() - 1);

		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list = new ArrayList<Integer>(Arrays.asList(1, 2, 2));
		System.out.print(subsets(list).toString());

	}

}
