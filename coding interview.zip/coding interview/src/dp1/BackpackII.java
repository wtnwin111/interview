package dp1;

public class BackpackII {
	/*
	 * Given n items with size Ai and value Vi, and a backpack with size m.
	 * What's the maximum value can you put into the backpack?
	 * Example
	 * Given 4 items with size [2, 3, 5, 7] and value [1, 5, 2, 4], and a
	 * backpack with size 10. The maximum value is 9.
	 */
	/**
	 * f[m]= max f[m-a[i]]+v[i], init f[0-m]=0,
	 *
	 * @param m
	 *            : An integer m denotes the size of a backpack
	 * @param A
	 *            & V: Given n items with size A[i] and value V[i]
	 * @return: The maximum value
	 */
	public int backPackII(int m, int[] a, int v[]) {
		int f[] = new int[m + 1];
		for (int i = 0; i < m + 1; i++) {
			f[i] = 0;
		}
		for (int i = 0; i < a.length; i++) {
			for (int j = m; j >= a[i]; j--) {
				f[j] = Math.max(f[j], f[j - a[i]] + v[i]);
			}
		}
		return f[m];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
