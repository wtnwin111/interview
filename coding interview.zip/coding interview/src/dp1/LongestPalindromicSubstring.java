/**
 *
 */
package dp1;

/**
 * Given a string S, find the longest palindromic substring in S. You may assume
 * that the maximum length of S is 1000, and there exists one unique longest
 * palindromic substring.
 * Example
 * Given the string = "abcdzdcab", return "cdzdc".
 *
 * @author K25553
 *
 */
public class LongestPalindromicSubstring {
	/**
	 * @param s
	 *            input string
	 * @return the longest palindromic substring
	 *
	 *         dp[i][j]
	 */

	public static String longestPalindrome(String s) {
		if (s.length() < 2 || s == null) {
			return s;
		}

		int ct;
		int max = 1;
		String ans = s.substring(0, 0);
		for (int i = 0; i < s.length(); i++) {
			ct = 1;
			int p1 = i - 1, p2 = i + 1;
			while (p1 >= 0 && p2 < s.length() && s.charAt(p1) == s.charAt(p2)) {
				ct += 2;
				p1--;
				p2++;
			}

			max = Math.max(max, ct);
			if (max == ct) {
				ans = s.substring(p1 + 1, p2);
			}
			p1 = i;
			p2 = i + 1;
			if (p2 < s.length()) {
				ct = 0;
				while (p1 >= 0 && p2 < s.length()
						&& s.charAt(p1) == s.charAt(p2)) {
					ct += 2;
					p1--;
					p2++;
				}

				max = Math.max(max, ct);
				if (max == ct) {
					ans = s.substring(p1 + 1, p2);
				}
			}
		}

		return ans;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(longestPalindrome("bb"));

	}

}
