/**
 *
 */
package dp1;

/**
 * There is a stone game.at the beginning of the game the player picks n piles
 * of stones in a line.
 *
 * The goal is to merge the stones in one pile observing the following rules:
 *
 * at each step of the game,the player can merge two adjacent piles to a new
 * pile.
 * The score is the number of stones in the new pile.
 * You are to determine the minimum of the total score.
 * For [4, 1, 1, 4], in the best solution, the total score is 18:
 *
 * 1. Merge second and third piles => [4, 2, 4], score +2
 * 2. Merge the first two piles => [6, 4]��score +6
 * 3. Merge the last two piles => [10], score +10
 *
 * @author K25553
 *
 */
public class StoneGame {
	/**
	 * @param a
	 *            an integer array
	 * @return an integer
	 */
	public static int stoneGame(int[] a) {
		if (a == null || a.length == 0) {
			return 0;
		}
		int len = a.length;
		int[][] f = new int[len][len];
		int[][] sum = new int[len][len];
		boolean[][] visited = new boolean[len][len];

		for (int i = 0; i < len; i++) {
			f[i][i] = 0;
			sum[i][i] = a[i];
			visited[i][i] = true;

			for (int j = i + 1; j < len; j++) {
				sum[i][j] = sum[i][j - 1] + a[j];
			}

		}

		return msearch(0, len - 1, a, f, visited, sum);
	}

	private static int msearch(int l, int r, int[] a, int[][] f,
			boolean[][] visited, int[][] sum) {
		if (visited[l][r] == true) // including l=r and l=r-1

		{
			return f[l][r];
		}

		// if (l>r){
		// f[l][r]= Integer.MAX_VALUE;
		// }
		f[l][r] = Integer.MAX_VALUE;
		for (int i = l; i < r; i++) {
			f[l][r] = Math.min(f[l][r], msearch(l, i, a, f, visited, sum)
					+ msearch(i + 1, r, a, f, visited, sum) + sum[l][r]);
		}
		visited[l][r] = true;
		return f[l][r];
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO auto-generated method stub
		int a[] = { 16, 11, 7, 17, 11, 7, 9, 2, 17, 20, 22, 7, 5, 17, 6, 14,
				21, 2, 9, 2, 15, 20, 14, 6, 12, 16, 9, 8, 14, 5, 1, 12, 4, 19,
				5, 14, 22, 20, 13, 12, 19, 14, 3, 6, 17, 21, 13, 17, 8, 9, 18,
				1, 8, 12, 5, 20, 2, 7, 14, 22, 14, 7, 12, 20, 22, 2, 13, 15, 9,
				14, 20, 13, 3, 18, 8, 10, 20, 10, 18, 21 };
		System.out.println(stoneGame(a));

	}

}
