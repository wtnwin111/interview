package string;

public class CharacterStatictics {
	 
    public static void main(String[] args) {
 
        int chineseCharCount = 0;
        int spaceCount = 0;
        int digitCount = 0;
        int lettersCount = 0;
        int otherChars = 0;
 
        String value = "Hello world! Welcome to Java world! 1234567890 Java �ַ�ͳ�Ƹ���С����";
        char[] chars = value.toCharArray();
        for (char c : chars) {
            if (isChineseCharacter(c)) {
                chineseCharCount++;
            } else if (Character.isLetter(c)) {
                lettersCount++;
            } else if (Character.isDigit(c)) {
                digitCount++;
            } else if (' ' == c) {
                spaceCount++;
            } else {
                otherChars++;
            }
        }
 
        System.out.println("�����ַ�:" + chineseCharCount);
        System.out.println("����:" + digitCount);
        System.out.println("��ĸ:" + lettersCount);
        System.out.println("�ո�:" + spaceCount);
        System.out.println("�����ַ�:" + otherChars);
 
    }
 
    private static boolean isChineseCharacter(char c) {
        return c >= '\u4E00' && c <= '\u9FBF';
    }
 
}