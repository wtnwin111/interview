package string;
public class StringComparision1 {

	public static void main(String[] args) {
		String name1 = "Bob";
		String name2 = new String("Bob");
		String name3 = "Bob";
		System.out.println((double)12.000+(int)12);
		System.out.println((long)12.000+(int)12);
		System.out.println(12.00/0);
		// 1st case
		if (name1 == name2) {
			System.out.println("The strings are equal.");
		} else {
			System.out.println("The strings are unequal.");
		}
		// 2nd case
		if (name1 == name3) {
			System.out.println("The strings are equal.");
		} else {
			System.out.println("The strings are unequal.");
		}
		
		if (name1.equals(name2)) {
			System.out.println("The strings are equal.");
		} else {
			System.out.println("The strings are unequal.");
		}
	}
}