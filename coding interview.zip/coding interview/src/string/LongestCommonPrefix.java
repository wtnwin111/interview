/**
 * 
 */
package string;

/**
 * @author Tiannan
 *
 */
public class LongestCommonPrefix {

	/**
	 * @param args
	 * 

Given k strings, find the longest common prefix (LCP).

Example 

For strings "ABCD", "ABEF" and "ACEF", the LCP is "A"

For strings "ABCDEFG", "ABCEFG" and "ABCEFA", the LCP is "ABC"

prefix< string.len,
1 for each char i of string, check each sting j in array, increase j, j< array.len, prefix 0-i

2 for each string 
	 */
	public static String longestCommonPrefix(String[] strs) {
        // write your code here
		if(strs==null&&strs.length==0){
			return ""; }
		String prefix= strs[0];
		for (int i=1; i<strs.length;i++){
			int j= 0;
			while(j<strs[i].length()&&j<prefix.length()&&strs[i].charAt(j)==prefix.charAt(j)){
				j++;
			}
		prefix = prefix.substring(0, j);
		}
		return prefix;
	
	}
	public static void main(String[] args) {
		String[] strs= {"ABCD", "ABEF","ACEF"};
		String[] st1={ "ABCDEFG", "ABCEFG","ABCEFA"};
		System.out.println( longestCommonPrefix(strs).toString());
		System.out.println(longestCommonPrefix(st1).toString());
	}



	

}
