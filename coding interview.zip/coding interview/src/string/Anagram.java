
package string;
import java.util.Arrays;
/**
 * @author Tiannan
 *
 */
public class Anagram {

	/**
	 * Determines if two strings are anagrams. Whitespace is ignored, but all other characters

	 * (including punctuation) count.

	 * @param s1 first string to compare

	 * @param s2 second string to compare

	 * @return true if s1 and s2 are anagrams, false otherwise
	 */
	public static boolean areAnagrams(String s1, String s2) {
		char[] ch1 = s1.replaceAll("\\s+", "").toCharArray();
		char[] ch2 = s2.replaceAll("\\s+", "").toCharArray();
		Arrays.sort(ch1);

		Arrays.sort(ch2);

		return Arrays.equals(ch1, ch2);
	}
	//1len, 2 num of unique ele 3 int char array, loop for both: a:set ++, unnique++, b check; set--, (optional)unique==new unique processed: 
	public static boolean anagram2(String s, String t){
		if(s.length()!=t.length()){
			return false;
		}
	char[] s1= s.toCharArray();
	char[] s2=t.toCharArray();
	int a= s1.length-1;
	int b= 0;
	while(a>=0)
	{
		if (s1[a]!=s2[b]){
			return false;
		}
		a--;
		b++;
	}
	return true;
	}
	public static boolean anagram3(String s, String t){
		if(s.length()!=t.length()){
			return false;
		}
		int[]c = new int[128];
		char[] a= s.toCharArray();
		int num_unique_chars = 0;
		int num_completed_t = 0;
		for(char b: a){
			if(c[b]==0){
				++num_unique_chars;
			}
			c[b]++;
		}
		for(int i=0; i<t.length();i++){
			int f= t.charAt(i);
			
			if (--c[f]<0){
				return false;
			}
			if(c[f]==0){
				++num_completed_t;
			}
		}
		if(num_completed_t==num_unique_chars)
		return true;
		return false;
	}
	public static void main(String arg[]){
		String[][] pairs = {{"apple", "papel"}, {"carrot", "tarroc"}, {"hello", "llloh"},{"asd","dsa"}};
		for (String[] pair : pairs) {
			String word1 = pair[0];
			String word2 = pair[1];
			boolean anagram = anagram2(word1, word2);
			boolean anagram1 = areAnagrams(word1, word2);
			boolean anagram2 = anagram3(word1, word2);
			System.out.println(word1 + ", " + word2 + ": " + anagram);
			
			System.out.println(word1 + ", " + word2 + ": " + anagram1);
			System.out.println(word1 + ", " + word2 + ": " + anagram2);
			
		}
	}
}

