package base;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class Person {
	private String fistName;
	private String LastName;
	private AgeGroup ageGroup;
	public AgeGroup getAgeGroup() {
		return ageGroup;
	}
	public Person(String first, String last, AgeGroup age){
		this.fistName=first;
		this.LastName=last;
		this.ageGroup=age;
		
	}
	public void setAgeGroup(AgeGroup ageGroup) {
		this.ageGroup = ageGroup;
	}

	public enum AgeGroup{
		MINIOR, SENIOR, ADULT
	}


	public String getFistName() {
		return fistName;
	}
	public void setFistName(String fistName) {
		this.fistName = fistName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	@Override
	public String toString(){
		return "Person:["+this.fistName+""+this.LastName+""+this.ageGroup;
		
	}
	public static void main(String[] args) {
		List<Person>list =new ArrayList<Person>();
		list.add(new Person("1","2",Person.AgeGroup.ADULT));
		list.add(new Person("1","3",Person.AgeGroup.ADULT));
		list.add(new Person("1","4",Person.AgeGroup.ADULT));
		list.add(new Person("1","4",Person.AgeGroup.MINIOR));
		list.add(new Person("1","4",Person.AgeGroup.SENIOR));
		list.add(new Person("1","4",Person.AgeGroup.SENIOR));
		list=Person.getSortedListByAgeGroupFirstNameAndLastName(list);
		for(Person p :list){    
			System.out.println(p);
		}

	}
	public static List<Person> getSortedListByAgeGroupFirstNameAndLastName(List<Person> input){
		Comparator<Person> comp= new Comparator<Person>(){
			@Override
			public int compare(Person a, Person b){
				if(a.getAgeGroup().compareTo(b.getAgeGroup())==0){
					if (a.getFistName().compareTo(b.getFistName())==0){
						return a.getLastName().compareTo(b.getLastName());
					}return a.getFistName().compareTo(b.getFistName());
				} 
				return a.getAgeGroup().compareTo(b.ageGroup);
			}

		};
		Collections.sort(input,comp);
		return input;

	}
}
