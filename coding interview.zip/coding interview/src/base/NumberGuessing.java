package base;

import java.util.Scanner;

public class NumberGuessing {

	public static int numGuess = 0;

	public void run() {
		Scanner scanner = new Scanner(System.in);
		int guess = (int) Math.round(Math.random() * 1000);
		//assume the guess range from 0 to 1000
		int min = 0, max = 1000;

		System.out.println("Let's play a game: Think of a nubmer between 0 and 1000, and I'll try to guess, ready? (yes/no)");
		String decision = scanner.next().toLowerCase();

		if ("yes".equals(decision)) {
			while (min != max) {
				numGuess++;
				System.out.println("Is it " + guess + "?\t(Less/Greater/Yes)");
				decision = scanner.next().toLowerCase();
				if ("less".equals(decision)) {
					max = guess;
					//     guess = min + (int) Math.round((guess - min) * Math.random());
					guess = (min + guess) / 2;
				}
				else if ("greater".equals(decision)){
					min = guess;
					//     guess = guess + (int) Math.round((max - guess) * Math.random());
					guess = (guess + max) / 2;
				}
				else if("yes".equalsIgnoreCase(decision)){
					System.out.println("Bingo! Your number is " + guess + "!");
					scanner.close();
					break;
				}else{
					System.out.println("wrong input please follow the correct intruction!");
					numGuess--;
					continue;
				}
			}

			if (min == max) {
				System.out.println("Bingo! Your number is " + max + "!");
			}

			System.out.println("My total nubmer of guesses is " + numGuess + "!");
		}
	}

	public static void main(String[] args) {
		NumberGuessing guess = new NumberGuessing();
		guess.run();
	}
}