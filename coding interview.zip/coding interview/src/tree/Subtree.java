/**
 *
 */
package tree;

/**
 * You have two every large binary trees: T1, with millions of nodes, and T2,
 * with hundreds of nodes. Create an algorithm to decide if T2 is a subtree of
 * T1.
 * Example
 * //T2 is a subtree of T1 in the following case:
 * //
 * // 1 3
 * // / \ /
 * //T1 = 2 3 T2 = 4
 * // /
 * // 4
 * //T2 isn't a subtree of T1 in the following case:
 * //
 * // 1 3
 * // / \ \
 * //T1 = 2 3 T2 = 4
 * // /
 * // 4
 *
 * @author K25553
 *
 */
public class Subtree {
	/**
	 * @param T1
	 *            , T2: The roots of binary tree.
	 * @return: True if T2 is a subtree of T1, or false.
	 */
	public boolean isSubtree(TreeNode t1, TreeNode t2) {

		if (t2 == null) {
			return true;
		}
		if (t1 == null) {
			return false;
		}
		if (isEqual(t1, t2)) {
			return true;
		}
		// if (t1.val == t2.val) {
		// return isEqual(t1,t2);
		// }
		// imp: above wrong check one node if it is subtree, we should check
		// every node in tree for is subtree.
		// if (t1.val == t2.val&&isEqual(t1.left, t2.left) && isEqual(t1.right,
		// t2.right)) {
		// return true;
		// }
		return isSubtree(t1.left, t2) || isSubtree(t1.right, t2);
	}

	private boolean isEqual(TreeNode t1, TreeNode t2) {

		if (t2 == null || t1 == null) {
			return t1 == t2;
		}

		if (t1.val != t2.val) {
			return false;
		}
		return isEqual(t1.left, t2.left) && isEqual(t1.right, t2.right);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
