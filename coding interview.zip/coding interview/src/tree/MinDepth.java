package tree;



import java.util.LinkedList;
import java.util.Queue;

/**
 * Definition for binary tree
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
public class MinDepth{
    // SOLUTION 1:
    public int minDepth1(TreeNode root) {
      
        if (root == null) {
            return 0;
        }
        
        return dfs(root);
    }
    
    /*
     *  The Recursion Version:
     *    * */
    public int dfs(TreeNode root) {
        if (root == null) {
            return Integer.MAX_VALUE;
        }
        
        // The base case: the root is a leaf.
        if (root.left == null && root.right == null) {
            return 1;
        }
        
        return Math.min(dfs(root.left), dfs(root.right)) + 1;
    }
    
    // SOLUTION 2: 
    // Level Traversal:
    public int minDepth(TreeNode root) {
        /*
         
        */
        if (root == null) {
            return 0;
        }
        
        int level = 0;
        
        Queue<TreeNode> q = new LinkedList<TreeNode>();
        q.offer(root);
        
        while (!q.isEmpty()) {
            int size = q.size();
            level++;
            for (int i = 0; i < size; i++) {
               TreeNode cur = q.poll();
               
               if (cur.left == null && cur.right == null) {
                   return level;
               }
               
               if (cur.left != null) {
                   q.offer(cur.left);
               }
               
               if (cur.right != null) {
                   q.offer(cur.right);
               }
            }
        }
        
        return 0;
    }
    
    public int maxDepth(TreeNode root) {
        if (root == null) {
            return 0;
        }

        int left = maxDepth(root.left);
        int right = maxDepth(root.right);
        return Math.max(left, right) + 1;
    }
}