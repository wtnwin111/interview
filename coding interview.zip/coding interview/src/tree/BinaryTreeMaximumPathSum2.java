/**
 * 
 */
package tree;

/**
 *Given a binary tree, find the maximum path sum from root.

The path may end at any node in the tree and contain at least one node in it.




For example: 

Given the below binary tree, 

  1 

 /  \ 

2   3 

Return 6.
 * @author Tiannan
 * max path is from one node to the other node:
 * 1node to its root
 * 2node to its root to the other node in the other branch
 * 
 * 
 *2max path: globally the path that is max of all path, combines 1 (if the other brach is less than 0, discard )and 2, 
 *that is max(maxPath, left.singlePath + right.singlePath + root.val)
 *1single path: the local path of current node as root to its l or r branch
 *	if it is less than 0, discard it as 0
 *  
 */
public class BinaryTreeMaximumPathSum2 {
	  /**
     * @param root the root of binary tree.
     * @return an integer
     */
    public int maxPathSum2(TreeNode root) {
         if (root == null) {
            return 0;
        }
        
        int left = maxPathSum2(root.left);
        int right = maxPathSum2(root.right);
        return root.val + Math.max(0, Math.max(left, right));
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
