/**
 * 
 */
package tree;

/**
 * @author Tiannan
 *
 */
public class MinimumPathSum {
	/**
	 * @param grid: a list of lists of integers.
	 * @return: An integer, minimizes the sum of all numbers along its path
	 */
	public int minPathSum(int[][] grid) {

	}

}
