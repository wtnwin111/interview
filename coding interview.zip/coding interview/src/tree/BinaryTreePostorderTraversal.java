/**
 *
 */
package tree;

import java.util.ArrayList;
import java.util.Stack;

/**
 * Given a binary tree, return the preorder traversal of its nodes' values.
 * 
 * Have you met this question in a real interview? Yes
 * Example
 * Given binary tree {1,#,2,3}:
 * 
 * 1
 * \
 * 2
 * /
 * 3
 * return [1,2,3].
 * 
 * @author K25553
 *
 */
public class BinaryTreePostorderTraversal {
	/**
	 * @param root
	 *            : The root of binary tree.
	 * @return: Preorder in ArrayList which contains node values.
	 */
	public ArrayList<Integer> postorderTraversal(TreeNode root) {
		// write your code here
		ArrayList<Integer> result = new ArrayList<Integer>();
		traverse(root, result);
		return result;
	}

	private void traverse(TreeNode root, ArrayList<Integer> result) {
		// TODO Auto-generated method stub
		if (root == null) {
			return;
		}

		traverse(root.left, result);
		traverse(root.right, result);
		result.add(root.val);
	}

	// Recursive
	public ArrayList<Integer> postorderTraversal2(TreeNode root) {
		ArrayList<Integer> result = new ArrayList<Integer>();

		if (root == null) {
			return result;
		}

		result.addAll(postorderTraversal2(root.left));
		result.addAll(postorderTraversal2(root.right));
		result.add(root.val);

		return result;
	}

	// Iterative
	public ArrayList<Integer> postorderTraversal3(TreeNode root) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		Stack<TreeNode> stack = new Stack<TreeNode>();
		TreeNode prev = null; // previously traversed node
		TreeNode curr = root;

		if (root == null) {
			return result;
		}

		stack.push(root);
		while (!stack.empty()) {
			curr = stack.peek();
			// if current is not leave
			if (prev == null || prev.left == curr || prev.right == curr) { // traverse
																			// down
																			// the
																			// tree
				if (curr.left != null) {
					stack.push(curr.left);
				} else if (curr.right != null) {
					stack.push(curr.right);
				}
			} else if (curr.left == prev) { // traverse up the tree from the
											// left
				if (curr.right != null) {
					stack.push(curr.right);
				}
			} else { // traverse up the tree from the right
				result.add(curr.val);
				stack.pop();
			}
			prev = curr;
		}
		return result;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
