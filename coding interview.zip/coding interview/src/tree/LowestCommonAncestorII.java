/**
 * 
 */
package tree;

/**
 * Given the root and two nodes in a Binary Tree. Find the lowest common ancestor(LCA) of the two nodes.

The lowest common ancestor is the node with largest depth which is the ancestor of both nodes.

The node has an extra attribute parent which point to the father of itself. The root's parent is null.
 * @author K25553
 *
 */
public class LowestCommonAncestorII {
	class ParentTreeNode {
		     public ParentTreeNode parent, left, right;
		 }
	 /**
     * @param root: The root of the tree
     * @param A, B: Two node in the tree
     * @return: The lowest common ancestor of A and B
     */
    public ParentTreeNode lowestCommonAncestorII(ParentTreeNode root,
                                                 ParentTreeNode a,
                                                 ParentTreeNode b) {
        if (root==null){
			return null;
		}
		if(root==a||root==b){
			return root;
		}
		ParentTreeNode l = lowestCommonAncestorII(root.left, a ,b);
		ParentTreeNode r = lowestCommonAncestorII(root.right,a, b);
		if(l!=null&&r!=null){
			return root;
		}
		else if(l!=null){
			return l;
		}
		else if(r!=null){
			return r;
		}else{
			return null;
		}
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
