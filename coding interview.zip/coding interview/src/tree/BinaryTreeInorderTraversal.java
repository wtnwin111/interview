/**
 *
 */
package tree;

import java.util.ArrayList;
import java.util.Stack;

/**
 * @author K25553
 *
 */
public class BinaryTreeInorderTraversal {
	/**
	 * @param root
	 *            : The root of binary tree.
	 * @return: Inorder in ArrayList which contains node values.
	 */
	public ArrayList<Integer> inorderTraversal(TreeNode root) {
		ArrayList<Integer> res = new ArrayList<Integer>();
		if (root != null) {
			inorder(root, res);
		}
		return res;
	}

	private void inorder(TreeNode root, ArrayList<Integer> res) {
		if (root.left == null && root.right == null) {
			res.add(root.val);
			return;
		}
		if (root.left != null) {
			inorder(root.left, res);
		}
		res.add(root.val);
		if (root.right != null) {
			inorder(root.right, res);
		}
	}

	/**
	 * @param root
	 *            : The root of binary tree.
	 * @return: Inorder in ArrayList which contains node values.
	 *          until root is null or stack is empty, add all root and left node
	 *          to stack, then pop add res (left and root);
	 *          then root become right node,
	 */
	public ArrayList<Integer> inorderTraversal1(TreeNode root) {
		Stack<TreeNode> stack = new Stack<TreeNode>();
		ArrayList<Integer> result = new ArrayList<Integer>();
		TreeNode curt = root;

		while (curt != null || !stack.empty()) {
			while (curt != null) {
				stack.add(curt);
				curt = curt.left;
			}
			curt = stack.peek();
			stack.pop();
			result.add(curt.val);
			curt = curt.right;
		}
		return result;
	}

	public ArrayList<Integer> inorderTraversal2(TreeNode root) {

		Stack<TreeNode> stack = new Stack<TreeNode>();
		ArrayList<Integer> res = new ArrayList<Integer>();
		if (root == null) {
			return res;
		}
		stack.push(root);
		while (!stack.empty()) {

			root = stack.peek();

			if (root.right != null) {
				stack.push(root.right);
			}
			if (root.left != null) {
				stack.push(root.left);
				root.left = null;
				root.right = null;

			} else {
				stack.pop();
				res.add(root.val);
			}
		}
		return res;

	}
}
