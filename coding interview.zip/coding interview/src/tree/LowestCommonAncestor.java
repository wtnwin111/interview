/**
 * 
 */
package tree;

import java.util.ArrayList;

/**
 * Given the root and two nodes in a Binary Tree. Find the lowest common ancestor(LCA) of the two nodes.

The lowest common ancestor is the node with largest depth which is the ancestor of both nodes.


Example 

For the following binary tree:
  4
 / \
3   7
   / \
  5   6


LCA(3, 5) = 4

LCA(5, 6) = 7

LCA(6, 7) = 7

 * @author Tiannan
 *
 */
public class LowestCommonAncestor {



	//Version 2: Divide & Conquer
	 // ��rootΪ���Ķ���������A,B��LCA:
    // ����ҵ��˾ͷ������LCA, if both sides are not null, return root
    // ���ֻ����A���ͷ���A		if left is not null but right is null, return left 
    // ���ֻ����B���ͷ���B		if right is null but left is not null, return right 
    // �����û�У��ͷ���null		both are null return null



	private TreeNode lowestCommonAncestor(TreeNode root, TreeNode node1, TreeNode node2) {
		if (root == null || root == node1 || root == node2) {
			return root;
		}

		// Divide
		TreeNode left = lowestCommonAncestor(root.left, node1, node2);
		TreeNode right = lowestCommonAncestor(root.right, node1, node2);

		// Conquer
		// if left or right ==null means ele does not is left subtree or right subtree 
		// if left has one ele and right has one, then return current root.  
		if (left != null && right != null) {
			return root;
		} 
		//if only left has bogheles then
		if (left != null) {
			return left;
		}
		if (right != null) {
			return right;
		}
		return null;
	}
    public TreeNode lowestCommonAncestor1(TreeNode root, TreeNode p, TreeNode q) {
        // 1439.
        // 1. Two nodes are on left, go left.
        // 2. Two nodes are on right, go right.
        // 3. They are in both sides, return root.
        // if root == null, return null.
        if (root == null) {
            return null;
        }
        
        if (p.val < root.val && q.val < root.val) {
            return lowestCommonAncestor1(root.left, p, q);
        } else if (p.val > root.val && q.val > root.val) {
            return lowestCommonAncestor1(root.right, p, q);
        } else {
            return root;
        }
    }
	private ArrayList<TreeNode> getPath2Root(TreeNode node) {
        ArrayList<TreeNode> list = new ArrayList<TreeNode>();
        while (node != null) {
            list.add(node);
          //  node = node.parent;
        }
        return list;
    }
    public TreeNode lowestCommonAncestor(TreeNode node1, TreeNode node2) {
        ArrayList<TreeNode> list1 = getPath2Root(node1);
        ArrayList<TreeNode> list2 = getPath2Root(node2);
        
        int i, j;
        for (i = list1.size() - 1, j = list2.size() - 1; i >= 0 && j >= 0; i--, j--) {
            if (list1.get(i) != list2.get(j)) {
               // return list1.get(i).parent;
            }
        }
        return list1.get(i+1);
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
