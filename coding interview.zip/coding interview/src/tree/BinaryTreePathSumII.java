package tree;

import java.util.ArrayList;
import java.util.List;

/**Your are given a binary tree in which each node contains a value. Design an algorithm to get all paths which sum to a given value. The path does not need to start or end at the root or a leaf, but it must go in a straight line down.

 Have you met this question in a real interview? Yes
 Example
 Given a binary tree:

 1
 / \
 2   3
 /   /
 4   2
 for target = 6, return

 [
 [2, 4],
 [1, 3, 2]
 ]
 * Created by K25553 on 7/6/2016.
 */
public class BinaryTreePathSumII {

    /**
     * @param root   the root of binary tree
     * @param target an integer
     * @return all valid paths
     */
    public List<List<Integer>> binaryTreePathSum2(TreeNode root, int target) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) {
            return result;
        }
        ArrayList<Integer> path = new ArrayList<>();
        path.add(root.val);
        if (root.val == target) {
            result.add(path);
        }
        helper(root.left, path, root.val, target, result);
        helper(root.right, path, root.val, target, result);
        return result;
    }

    private void helper(TreeNode root,
                        ArrayList<Integer> path,
                        int sum,
                        int target,
                        List<List<Integer>> result) {
        if (root == null) {
            return;
        }
        path.add(root.val);
        sum+= root.val;
        if (sum==target){
            result.add(new ArrayList<Integer>(path));
        }
        List<List<Integer>>  res = binaryTreePathSum2(root,target);
        if (!res.isEmpty()){
            result.addAll(res);
        }
        //leave
        if(root.left==null&&root.right==null)
        {
            return;
        }

        if(root.left!=null)

        {
            path.add(root.left.val);
            helper(root.left, path, sum + root.left.val, target, result);
            path.remove(path.size() - 1);
        }

        if(root.right!=null)

        {
            path.add(root.right.val);
            helper(root.right, path, sum + root.right.val, target, result);
            path.remove(path.size() - 1);
        }

    }
}
