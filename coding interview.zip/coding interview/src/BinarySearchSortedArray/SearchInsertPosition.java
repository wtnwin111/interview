/**
 * 
 */
package BinarySearchSortedArray;

/**
 * @author Tiannan
 *
 */
public class SearchInsertPosition {

	/**
	 * Given a sorted array and a target value, return the index if the target is found. If not, return the index where it would be if it were inserted in order.

You may assume NO duplicates in the array.

Example 

[1,3,5,6], 5 �� 2

[1,3,5,6], 2 �� 1

[1,3,5,6], 7 �� 4

[1,3,5,6], 0 �� 0

Challenge 

O(log(n)) time

	 */
	
	 /** 
     * param A : an integer sorted array
     * param target :  an integer to be inserted
     * return : an integer
     */
	public static int searchInsert1(int[] a, int target) {
		int start=0, end=a.length-1,  mid ;
		while(start+1<end){
			mid=start+(end-start)/2;
			if(a[mid]==target){
				return mid;
			}else if (a[mid]<target){
				start=mid;
			}else {
				end=mid;
			}
		}
		
		if(end==target){
			return end;
		}else if (end<target){
			return end+1;
		}else if (start==target){
			return start;
		}else {
			return start+1;
		}
	}
    public static int searchInsert(int[] A, int target) {
        // write your code here
    	if (A.length == 0) {
            return 0;
        }

        int start = 0;
        int end = A.length - 1;
        int mid;

        while (start + 1 < end) {
            mid = start + (end - start) / 2;
            if (A[mid] == target) {
                end = mid;
            } else if (A[mid] < target) {
                start = mid;
            } else if (A[mid] > target) {
                end = mid;
            }
        }

        if (A[start] >= target) {
            return start;
        }else
        if (A[end] >= target) {
            return end;
        }else {
        	return end+1;

    }

    	
    }
	public static void main(String[] args) {
		int[] test= {1,3,5,6};
		
		
		System.out.println(searchInsert(test, 5));

	}

}
