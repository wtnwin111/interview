/**
 * 
 */
package BinarySearchSortedArray;

/**
 * @author Tiannan
 *
 */
public class FindMissingNum {

	/**
	 * @param args
	 */
	static int findMissingNumber (int arr[]) { 
		 if (arr.length == 0||arr.length == 1) {
	            return -1;
	        }
		int i=1;
		int j=0;
		while(i<arr.length){
			if(arr[i]-arr[j]==1){
				++j;
			}
			else{
				return ++arr[j];
			}
			i++;
		}
		return -1;
	
		
	}
	
	static int findMissingNumber2 (int a[]) { 
		 if (a.length == 0||a.length == 1) {
	            return -1;
	        }
		int s=0, e=a.length-1,m;
		while(s+1<e){
			m=s+(e-s)/2;
			if(a[m]-a[s]>m-s){
				e=m;
			}else if (a[e]-a[m]>e-m){
				s=m;
			}else {
				return -1;
			}
		}
		
		if(a[e]-a[s]>1){
			return ++a[s];
		}
		
		return -1;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a1[] ={4,5,6,7,9,11,14,15,17};
		int a2[] ={4,5,6,7,9,11,14,15,17};
		System.out.println(findMissingNumber(a1));
		System.out.println(findMissingNumber2(a2));
		
	}

}
