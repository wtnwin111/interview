/**
 * 
 */
package BinarySearchSortedArray;

/**
 * Find the last position of a target number in a sorted array. 
 * Return -1 if target does not exist.
 * @author K25553
 *
 */
public class LastPositionofTarget {
	  /**
     * @param A an integer array sorted in ascending order
     * @param target an integer
     * @return an integer
     */
    public int lastPosition(int[] nums, int target) {

        //write your code here
    	if(nums.length==0){
    		return -1;
    	}
    	int start=0, end=nums.length-1, mid;
    	while(start+1<end){
    		mid= start+(end-start)/2;
    		if(nums[mid]==target){
    			start=mid;
    		}else if(nums[mid]<target){
    			start=mid;
    		}else{
    			end=mid;
    		}
    	}
    	if(nums[end]==target){
    		return end;
    	}else if(nums[start]==target){
    		return start;
    	}
    	
    	return -1;
    
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
