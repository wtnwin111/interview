/**
 * 
 */
package BinarySearchSortedArray;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**Given a sorted array of n integers, find the starting and ending position of a given target value.

If the target is not found in the array, return [-1, -1].


Example
Given [5, 7, 7, 8, 8, 10] and target value 8, return [3, 4].

Challenge
O(log n) time.
 * @author Tiannan
 *anlysis: 888 in a consistent sequence, target to the first and last of index of 8
 *binary search first -- left bound and last index -- right bound 
 */
public class SearchforaRange {
	public static int[] searchRange(int[] A, int target) {
        int start, end, mid;
        int[] bound = new int[2]; 
        
        // search for left bound
        start = 0; 
        end = A.length - 1;
        while (start + 1 < end) {
            mid = start + (end - start) / 2;
            if (A[mid] == target) {
                end = mid;
            } else if (A[mid] < target) {
                start = mid;
            } else {
                end = mid;
            }
        }
        if (A[start] == target) {
            bound[0] = start;
        } else if (A[end] == target) {
            bound[0] = end;
        } else {
            bound[0] = bound[1] = -1;
            return bound;
        }
        
        // search for right bound
        start = 0;
        end = A.length - 1;
        while (start + 1 < end) {
            mid = start + (end - start) / 2;
            if (A[mid] == target) {
                start = mid;
            } else if (A[mid] < target) {
                start = mid;
            } else {
                end = mid;
            }
        }
        if (A[end] == target) {
            bound[1] = end;
        } else if (A[start] == target) {
            bound[1] = start;
        } else {
            bound[0] = bound[1] = -1;
            return bound;
        }
        
        return bound;
    }
	 public static ArrayList<Integer> searchRange(List<Integer> A, int target) {
        int start, end, mid;
        ArrayList<Integer> bound = new ArrayList<Integer>() ; 
        if (A.size()==0||A==null){
        	bound.add(-1);
        	bound.add(-1);
        	return bound;
        }
        // search for left bound
        start = 0; 
        end = A.size() - 1;
        while (start + 1 < end) {
            mid = start + (end - start) / 2;
            if (A.get(mid) == target) {
                end = mid;
            } else if (A.get(mid) < target) {
                start = mid;
            } else {
                end = mid;
            }
        }
        if (A.get(start) == target) {
            bound.add(0,start);
        } else if (A.get(end) == target) {
            bound.add(0,end);
        } else {
        	 bound.add(0, -1);  bound.add(1, -1);
            return (ArrayList<Integer>) bound;
        }
        
        // search for right bound
        start = 0;
        end = A.size() - 1;
        while (start + 1 < end) {
            mid = start + (end - start) / 2;
            if (A.get(mid) == target) {
                start = mid;
            } else if (A.get(mid) < target) {
                start = mid;
            } else {
                end = mid;
            }
        }
        if (A.get(end) == target) {
            bound.add(1, end);
        } else if (A.get(start) == target) {
            bound.add(1, start);
        } else {
            bound.add(0, -1);  bound.add(1, -1);
            return (ArrayList<Integer>) bound;
        }
        
        return (ArrayList<Integer>) bound;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= searchRange(new int[] {5, 7, 7, 8, 8, 10}, 5);
		for(int b:a){
			System.out.println( b);
		}
		int[]b = new int[] {5, 7, 7, 8, 8, 10};
		List<Integer>c=Arrays.asList(5, 7, 7, 8, 8, 10);
		List<Integer> a1= new ArrayList<Integer>(searchRange(c, 8));
		for(Integer b1:a1){
			System.out.println( b1);
		}
		
	}

}
