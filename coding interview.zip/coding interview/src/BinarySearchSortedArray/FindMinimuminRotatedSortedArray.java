/**
 * 
 */
package BinarySearchSortedArray;

/**Suppose a sorted array is rotated at some pivot unknown to you beforehand.

(i.e., 0 1 2 4 5 6 7 might become 4 5 6 7 0 1 2).

Find the minimum element.

Example 

Given [4, 5, 6, 7, 0, 1, 2] return 0

Note 
 * @author Tiannan
 *
 */
public class FindMinimuminRotatedSortedArray {
	 public int findMin(int[] num) {
	        int start = 0, end = num.length - 1;
	        while (start + 1 < end) {
	            int mid = start + (end - start) / 2;
	            if (num[mid] >= num[end]) {
	                start = mid;
	            } else {
	                end = mid;
	            }
	        }
	        if (num[start] < num[end]) {
	            return num[start];
	        } else {
	            return num[end];
	        }
	    }
	 //if there is dulpicated ele then binary search will fail
	 //hence loop throught 0-n-1
	 public int findMin1(int[] num) {
	        int min = num[0];
	        for (int i = 1; i < num.length; i++) {
	            if (num[i] < min)
	                min = num[i];
	        }
	        return min;
	    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
