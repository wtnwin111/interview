package BinarySearchSortedArray;

public class DulplicateRangeInSortedArray {
	public static int[] find(int [] a, int k){
		if (a==null ||a.length==0){
			return new int[]{
				-1,-1
			};
		}
		int []bound= new int[2];
		int start=0;
		int end=a.length-1;
		//left bound 
		while (start<end){
			int mid=start+(end-start)/2;
			if(a[mid]==k){
				end=mid;
			}else if (a[mid]<k){
				start=mid;
			}else{
				mid=end;
			}
		}
		
		if(a[start]==k){
			bound[0]=start;
		}else if(a[end]==k){
			bound[0]=end;
		}else{
			bound[0]=bound[1]=-1;
			return bound;
		}
		
		//right bound
		start = 0;
        end = a.length - 1;
		while(start<end){
			int mid= start+ (end-start)/2;
			if(a[mid]==k){
				start=mid;
			}else if(a[mid]>k){
				end=mid;
			}else{
				start=mid;
			}
		}
		if(a[end]==k){
			bound[1]=end;
		}else if(a[start]==k){
			bound[1]=start;
		}else{
			bound[0]=bound[1]=-1;
			return bound;
		}
		return bound;
	}
}

