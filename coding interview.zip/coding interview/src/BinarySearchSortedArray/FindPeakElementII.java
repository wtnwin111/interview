/**
 * 
 */
package BinarySearchSortedArray;

import java.util.ArrayList;
import java.util.List;

/**一个整数矩阵有如下一些特性：

相邻的整数都是不同的
矩阵有 n 行 m 列。
对于所有的 i < m, 都有 A[0][i] < A[1][i] && A[n - 2][i] > A[n - 1][i].
对于所有的 j < n, 都有 A[j][0] < A[j][1] && A[j][m - 2] > A[j][m - 1].
我们定义一个位置 P 是一个峰，如果有 A[j][i] > A[j+1][i] && A[j][i] > A[j-1][i] && A[j][i] > A[j][i+1] && A[j][i] > A[j][i-1]。

找出该矩阵的一个峰值元素，返回他的坐标。

样例
给一个矩阵：

[
  [1 ,2 ,3 ,4 ,5],
  [16,41,23,22,6],
  [15,17,24,21,7],
  [14,18,19,20,8],
  [13,12,11,10,9]
]
返回 41 的坐标[1,1], 或者 24 的坐标[2,2]。

注意
可能会存在多个峰值，返回任意一个即可。

挑战
使用 O(n) 的时间复杂度。

如果你想出了一个O(nlogn)的算法，能否证明他的复杂度其实是O(n)的？或者能不能想一个类似的算法但是复杂度是O(n)？

 * @author Tiannan
 *对于所有的 i < m, 都有 A[0][i] < A[1][i] && A[n - 2][i] > A[n - 1][i].
对于所有的 j < n, 都有 A[j][0] < A[j][1] && A[j][m - 2] > A[j][m - 1].
which means horizentally or vertically there is at least a peak ele
binary search vertically 
if a mid < a start
 */
public class FindPeakElementII {
    
     /**
     * @param A: An integer matrix
     * @return: The index of the peak
     */
    public List<Integer> findPeakII(int[][] A) {
        // write your code here
        int low = 1, high = A.length-2;
        List<Integer> ans = new ArrayList<Integer>();
        while(low <= high) {
            int mid = (low + high) / 2;
            int col = find(mid, A);
            if(A[mid][col] < A[mid - 1][col]) {
                high = mid - 1;
            } else if(A[mid][col] < A[mid + 1][col]) {
                low = mid + 1;
            } else {
                ans.add(mid);
                ans.add(col);
                break;
            }
        }
        return ans;
    }
    int find(int row, int [][]A) {
        int col = 0;
        for(int i = 0; i < A[row].length; i++) {
            if(A[row][i] > A[row][col]) {
                col = i;
            }
        }
        return col;
    } 


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a= {1, 2, 1, 3, 4, 5, 7, 6};
		System.out.println();
	}

}
