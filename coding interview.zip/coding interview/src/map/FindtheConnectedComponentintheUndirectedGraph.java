/**
 * 
 */
package map;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import epic.uniqueNumber;



/**Find the number connected component in the undirected graph. 
 * Each node in the graph contains a label and a list of its neighbors. 
 * (a connected component (or just component) of an undirected graph is 
 * a subgraph in which any two vertices are connected to each other 
 * by paths, and which is connected to no additional vertices in the supergraph.)
 * @author Tiannan
 * use bsf and hashmap (track status of visit)
 */
public class FindtheConnectedComponentintheUndirectedGraph {
	class UndirectedGraphNode {
		int label;
		ArrayList<UndirectedGraphNode> neighbors;
		UndirectedGraphNode(int x) { label = x; neighbors = new ArrayList<UndirectedGraphNode>(); }
	};
	/**
	 * @param nodes a array of Undirected graph node
	 * @return a connected set of a Undirected graph
	 */
	public List<List<Integer>> connectedSet(ArrayList<UndirectedGraphNode> nodes) {
		// Write your code here

		int m = nodes.size();
		Map<UndirectedGraphNode, Boolean> visited = new HashMap<>();

		for (UndirectedGraphNode node : nodes){
			visited.put(node, false);
		}

		List<List<Integer>> result = new ArrayList<>();

		for (UndirectedGraphNode node : nodes){
			if (visited.get(node) == false){
				bfs(node, visited, result);
			}
		}

		return result;
	}


	public void bfs(UndirectedGraphNode node, Map<UndirectedGraphNode, Boolean> visited, List<List<Integer>> result){
		
		List<Integer> list = new ArrayList<Integer>();
		Queue<UndirectedGraphNode> queue = new LinkedList<UndirectedGraphNode>();
		queue.offer(node);
		visited.put(node, true);
		while(!queue.isEmpty()){
			UndirectedGraphNode crt = queue.poll();
			list.add(crt.label);

			for(UndirectedGraphNode neighbor: crt.neighbors){
				if(visited.get(neighbor)==false){
					//must check the neighbor is visited, since each neighbor may connect to each other( circle), we must add the node that is unvisited
					queue.offer(neighbor);
					visited.put(neighbor,true);
				}
				
			}
		}
		Collections.sort(list);
		result.add(list);
	}
}
