/**
 * 
 */
package map;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * @author K25553
 * @param <T>
 *
 */
public class UnionFind<T> {
	Map<T, T> hm = new HashMap<T, T>();
	public UnionFind(HashSet<T> hs) {
		for(T a: hs){
			hm.put(a, a);
		}
	}
	
	public T  find(T x) {
		T father = hm.get(x);
		while (father!=hm.get(father)){
			father=hm.get(father);
		}
		//compress_find from link to star map
		T temp ;
		T next= hm.get(x);
		while(next!=hm.get(next) ){
			temp= hm.get(next);
			hm.put(next, father);
			next=temp;
		}
		return father;
	}
	
	public void union ( T x, T y){
		T fx= hm.get(x);
		T fy= hm.get(y);
		if (fx!= fy){
			hm.put(fx, fy);
		}
	}
	
}
