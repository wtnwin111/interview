package map;

import java.util.*;

/**
 * Six degrees of separation is the theory that everyone and everything is six or fewer steps away, by way of introduction, from any other person in the world, so that a chain of "a friend of a friend" statements can be made to connect any two people in a maximum of six steps.

 Given a friendship relations, find the degrees of two people, return -1 if they can not been connected by friends of friends.
 * Created by K25553 on 7/28/2016.
 */
public class SixDegrees {
    /**
     * @param graph a list of Undirected graph node
     * @param s,    t two Undirected graph nodes
     * @return an integer
     */

    public int sixDegrees(List<UndirectedGraphNode> graph,
                          UndirectedGraphNode s,
                          UndirectedGraphNode t) {


        if(t==s){
            return 0;
        }
        Map<UndirectedGraphNode,Integer> visited = new HashMap<>();
        Queue<UndirectedGraphNode> queue = new LinkedList<>();
        visited.put(s,0);queue.offer(s);
        while(!queue.isEmpty()){
            UndirectedGraphNode node = queue.poll();
            int degree = visited.get(node);
            for(UndirectedGraphNode neighbor:node.neighbors){
                if(visited.containsKey(neighbor)){
                    continue;
                }else{
                    if(neighbor==t){
                        return degree+1;
                    }
                    visited.put(neighbor,degree+1);

                    queue.offer(neighbor);

                }
            }
        }

        return -1;
    }
}
