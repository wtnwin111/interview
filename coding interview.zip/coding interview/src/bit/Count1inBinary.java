/**
 *
 */
package bit;

/**
 * Count how many 1 in binary representation of a 32-bit integer.
 * Example
 * Given 32, return 1
 *
 * Given 5, return 2
 *
 * Given 1023, return 9
 *
 * Challenge
 * If the integer is n bits with m 1 bits. Can you do it in O(m) time?
 *
 * @author K25553
 *         To find the negative of a number, in this representation, we invert
 *         all the bits and then add one bit. Adding one bit solves the problem
 *         of having two bits patterns representing 0. In this representation we
 *         only have one (00...0).
 *
 *         For exemple, we want to find the binary negative representation of 4
 *         (decimal) using 4 bits. First we convert 4 to binary:
 *
 *         4 = 0100
 *         then we invert all the bits
 *
 *         0100 -> 1011
 *         finally we add one bit
 *
 *         1011 + 1 = 1100.
 *         So 1100 is equivalent to -4 in decimal, if we are using a Two's
 *         Complement binary representation with 4 bits.
 */
public class Count1inBinary {
	/**
	 * @param num
	 *            : an integer
	 * @return: an integer, the number of ones in num
	 */
	public static int countOnes(int num) {
		int ct = 0;
		if (num < 0) {
			num = ~num;
			while (num != 0) {
				if (num % 2 == 1) {
					ct++;
				}
				num = num / 2;
			}
			return 32 - ct;
		}

		while (num != 0) {
			if (num % 2 == 1) {
				ct++;
			}
			num = num / 2;
		}
		return ct;
	}

	/*
	 * Unsigned shift >>> will not keep the sign bit (thus filling
	 * 0s).Arithmetic shift >> will keep the sign bit(if it is negative, then >>
	 * will fill with 1s).
	 */
	public static int countOnes1(int num) {
		int ct = 0;

		while (num != 0) {
			ct += num & 1;
			num = num >>> 1;
		}
		return ct;
	}

	/**
	 * n = 9 (1001)
	 * count = 0
	 * 
	 * Since 9 > 0, subtract by 1 and do bitwise & with (9-1)
	 * n = 9&8 (1001 & 1000)
	 * n = 8
	 * count = 1
	 * 
	 * Since 8 > 0, subtract by 1 and do bitwise & with (8-1)
	 * n = 8&7 (1000 & 0111)
	 * n = 0
	 * count = 2
	 * 
	 * Since n = 0, return count which is 2 now.
	 * 
	 * @param num
	 *            : an integer
	 * @return: an integer, the number of ones in num
	 */
	public static int countOnes2(int num) {
		int count = 0;
		while (num != 0) {
			num = num & (num - 1);
			count++;
		}
		return count;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i = -1;
		System.out.println(-1 >> 1);
	}

}
