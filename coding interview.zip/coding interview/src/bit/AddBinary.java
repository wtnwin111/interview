package bit;

/**
 * Given two binary strings, return their sum (also a binary string).

 Have you met this question in a real interview? Yes
 Example
 a = 11

 b = 1

 Return 100
 * Created by K25553 on 7/5/2016.
 *
 */
public class AddBinary {
    /**
     * @param a a number
     * @param b a number
     * @return the result
     */
    public static String addBinary(String a, String b) {
        int i = Integer.parseInt(a,2);
        int j = Integer.parseInt(b,2);
       while (j!= 0){
           //record res without carry
           int i1 = i^j;
           //record the carry
           int j1 = (i&j)<<1;
           i = i1;
           j = j1;
       }
       // System.out.println(i);

        String res="";
        if(i==0||i==1){
            return Integer.toString(i);
        }
        while(i>0){
            res= i%2 + res;
            i=i/2;
        }
       // System.out.println(res);
        return res;
    }
    public String addBinary1(String a, String b) {
        if(a.length() < b.length()){
            String tmp = a;
            a = b;
            b = tmp;
        }

        int pa = a.length()-1;
        int pb = b.length()-1;
        int carries = 0;
        String rst = "";

        while(pb >= 0){
            int sum = (int)(a.charAt(pa) - '0') + (int)(b.charAt(pb) - '0') + carries;
            rst = String.valueOf(sum % 2) + rst;
            carries = sum / 2;
            pa --;
            pb --;
        }

        while(pa >= 0){
            int sum = (int)(a.charAt(pa) - '0') + carries;
            rst = String.valueOf(sum % 2) + rst;
            carries = sum / 2;
            pa --;
        }

        if (carries == 1)
            rst = "1" + rst;
        return rst;
    }
    public static void main(String[] args) {
        System.out.println(addBinary("1010","1010"));

    }
}
