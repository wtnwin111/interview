/**
 * 
 */
package list;

import amazon.MergeTwoSortedLists.ListNode;

/**
 * ��һ��LinkedList, �Ѻ���reverse 1,2,3,4,5,6 -> 1,2,3,6,5,4.

Challenge 

Reverse it in-place and in one-pass

 * @author Tiannan
 *use dummy node to record the head
 *use head to 
 */
public class ReverseLinkedListIII {
	public class ListNode {
	      int val;
	      ListNode next;
	      ListNode(int val) {
	          this.val = val;
	        this.next = null;
	     }}
	 public void reverse(ListNode head) {
		 if (head== null || head.next == null) {
	            return;
	        }

	        ListNode fast, slow;
	        fast = head.next;
	        slow = head;
	        while (fast!=null || fast.next!=null) {  
	            fast = fast.next.next;
	            slow = slow.next;
	        } 
	        ListNode cur= slow.next;
	     	while(cur!=null){
	     		ListNode temp= cur.next;
	     		cur.next=slow;
	     		slow=cur;
	     		cur=temp;
	     	}
	 }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
