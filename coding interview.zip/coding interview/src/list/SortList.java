/**
 * 
 */
package list;

/**Sort a linked list in O(n log n) time using constant space complexity.
 * @author K25553
 *merge sort
 */
public class SortList {
	 public ListNode sortList(ListNode head) {
		if( head==null||head.next==null){
			return head;
		}
		ListNode mid = getMid(head);
		ListNode right =sortList(mid.next);
		mid.next=null;
		ListNode left = sortList(head);
		 
		 return merge(left,right);
		 
	 }
	 
	 private ListNode merge(ListNode left, ListNode right) {
		ListNode dummy = new ListNode(0);
		ListNode tail = dummy;
		while(left != null && right != null){
			if(left.val<right.val){
				tail.next=left;
				left=left.next;
			}else{
				tail.next=right;
				right=right.next;
			}
			tail=tail.next;
		}
		if(left != null){
			tail.next=left;
		}else{
			tail.next=right;
		}
		return dummy.next;
	}

	public ListNode getMid(ListNode head){
		ListNode fast=head.next, slow = head;
		while(fast !=null&&fast.next!=null){
			slow = slow.next;
			fast = fast.next.next;
		}
		return slow;
	 }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
