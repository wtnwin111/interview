package list;

/**You have two numbers represented by a linked list, where each node contains a single digit.
 * The digits are stored in reverse order, such that the 1's digit is at the head of the list.
 * Write a function that adds the two numbers and returns the sum as a linked list.
 * Given 7->1->6 + 5->9->2. That is, 617 + 295.

 Return 2->1->9. That is 912.

 Given 3->1->5 and 5->9->2, return 8->0->8.
 * Created by K25553 on 7/5/2016.
 */
public class AddTwoNumbers {
    /**
     * @param l1: the first list
     * @param l2: the second list
     * @return: the sum list of l1 and l2
     */
    public ListNode addLists(ListNode l1, ListNode l2) {
       String a = "", b="";
        ListNode dummy1 = new ListNode(0);
        ListNode tail1 = dummy1;
        tail1.next= l1;
        ListNode dummy2 = new ListNode(0);
        ListNode tail2= dummy2;
        tail2.next= l2;
        ListNode dummy3 = new ListNode(0);
        ListNode tail3= dummy3;
        //tail3.next= null;
        int carry = 0;
        while (tail1.next!=null||tail2.next!=null){
            while(tail1.next!=null&&tail2.next!=null)
            { int res= tail1.next.val+tail2.next.val+ carry;
                carry= res/10;
                tail3.next= new ListNode(res%10);
                tail3= tail3.next;
                tail1= tail1.next;
                tail2= tail2.next;
            }
            while(tail1.next!=null){
                int res= tail1.next.val+ carry;
                carry= res/10;
                tail3.next= new ListNode(res%10);
                tail3= tail3.next;
                tail1= tail1.next;
            }

            while(tail2.next!=null){
                int res= tail2.next.val+ carry;
                carry= res/10;
                tail3.next= new ListNode(res%10);
                tail3= tail3.next;
                tail2= tail2.next;
            }

        }
        if(carry==1){
            tail3.next= new ListNode(1);
        }
       return dummy3.next;
    }
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }
}
