/**
 * 
 */
package list;

/**You are given an n x n 2D matrix representing an image. Rotate the image by 90 degrees (clockwise).
Example 

Given a matrix
[
    [1,2],
    [3,4]
]


rotate it by 90 degrees (clockwise), return
[
    [3,1],
    [4,2]
]


Challenge 

Do it in-place.

 * @author Tiannan
 *
 */
public class RotateImage {
	 public void rotate(int[][] matrix) {
	        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) {
	            return;
	        }

	        int length = matrix.length;

	        for (int i = 0; i < length / 2; i++) {
	            for (int j = 0; j < (length + 1) / 2; j++){
	                int tmp = matrix[i][j];
	                matrix[i][j] = matrix[length - j - 1][i];
	                matrix[length -j - 1][i] = matrix[length - i - 1][length - j - 1];
	                matrix[length - i - 1][length - j - 1] = matrix[j][length - i - 1];
	                matrix[j][length - i - 1] = tmp;
	            }
	        }   
	    }
	 public int [][] rotate1(int [][] input){

		 int n =input.length;
		 int m = input[0].length;
		 int [][] output = new int [m][n];

		 for (int i=0; i<n; i++)
		 	for (int j=0;j<m; j++)
		 		output [j][n-1-i] = input[i][j];
		 return output;
		 }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
