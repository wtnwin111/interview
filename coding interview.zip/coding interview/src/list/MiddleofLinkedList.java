/**
 *
 */
package list;

/**
 * Example
 * Given 1->2->3, return the node with value 2.
 * 
 * Given 1->2, return the node with value 1.
 * 
 * @author K25553
 *
 */
public class MiddleofLinkedList {
	/**
	 * @param head
	 *            : the head of linked list.
	 * @return: a middle node of the linked list
	 */
	public ListNode middleNode(ListNode head) {
		// Write your code here
		if (head == null || head.next == null) {
			return head;
		}
		ListNode slow = head, fast = head.next;
		while (fast != null && fast.next != null) {
			slow = slow.next;
			fast = fast.next.next;
		}

		return slow;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
