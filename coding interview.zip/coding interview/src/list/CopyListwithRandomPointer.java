/**
 * 
 */
package list;

import java.util.HashMap;

/**
 * A linked list is given such that each node contains an additional random pointer which could point to any node in the list or null.

Return a deep copy of the list.
 * @author K25553
 *use hashmap to map old link(key) to new link (value)
 *1 deal with copy node of link
 *if head (old) is not in hashmap put in head, newNode(head);
 *else head was new ramdom and get value newNode
 *use preNode.next= newNode to copy to new link
 * 2 deal with copy of random node
 * if head.random is in map, newNode.random= map get head.random
 * else newNode.random= new node(head.random);  map.put(head.random, newNode.random);
 *  */
public class CopyListwithRandomPointer {
    /**
     * @param head: The head of linked list with a random pointer.
     * @return: A new head of a deep copy of the list.
     */

        public ListNode copyRandomList(ListNode head) {
            if (head == null) {
                return null;
            }

            HashMap<ListNode, ListNode> map = new HashMap<ListNode, ListNode>();
            ListNode dummy = new ListNode(0);
            ListNode pre = dummy, newNode;
            while (head != null) {
                if (map.containsKey(head)) {
                    newNode = map.get(head);
                } else {
                    newNode = new ListNode(head.val);
                    map.put(head, newNode);
                }
                pre.next = newNode;

                if (head.random != null) {
                    if (map.containsKey(head.random)) {
                        newNode.random = map.get(head.random);
                    } else {
                        newNode.random = new ListNode(head.random.val);
                        map.put(head.random, newNode.random);
                    }
                }

                pre = newNode;
                head = head.next;
            }

            return dummy.next;
        }
        private void copyNext(ListNode head) {
            while (head != null) {
                ListNode newNode = new ListNode(head.val);
                newNode.random = head.random;
                newNode.next = head.next;
                head.next = newNode;
                head = head.next.next;
            }
        }

        private void copyRandom(ListNode head) {
            while (head != null) {
                if (head.next.random != null) {
                    head.next.random = head.random.next;
                }
                head = head.next.next;
            }
        }

        private ListNode splitList(ListNode head) {
            ListNode newHead = head.next;
            while (head != null) {
                ListNode temp = head.next;
                head.next = temp.next;
                head = head.next;
                if (temp.next != null) {
                    temp.next = temp.next.next;
                }
            }
            return newHead;
        }

        public ListNode copyRandomList1(ListNode head) {
            if (head == null) {
                return null;
            }
            copyNext(head);
            copyRandom(head);
            return splitList(head);
        }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
