package list;

import java.util.HashMap;

/**
 * Design and implement a data structure for Least Recently Used (LRU) cache. It should support the following operations: get and set.

 get(key) - Get the value (will always be positive) of the key if the key exists in the cache, otherwise return -1.
 set(key, value) - Set or insert the value if the key is not already present. When the cache reached its capacity, it should invalidate the least recently used item before inserting a new item.
 * Created by K25553 on 7/19/2016.
 * Least recently used: least use: list (extract the node put it to tail-> most recently used, head->least recently used, use ) key value hashmap
 * listnode: pre next for linkedlist key value for hashmap
 * LRU ini: capacity head tail as dummy node, hashmap
 */
public class LRUCache {
    private class Node{
        Node pre;
        Node next;
        int key;
        int value;
        public Node (int key, int value){
            this.key= key;
            this.value= value;
            this.pre= null;
            this.next= null;
        }

    }
    private int capacity;
    private Node head = new Node(-1,-1);
    private Node tail = new Node(-1,-1);
    private HashMap<Integer,Node> hs = new HashMap<>();

    // @param capacity, an integer
    public LRUCache(int capacity) {
        this.capacity=capacity;
        this.tail.pre= this.head;
        this.head.next=tail;
    }

    // @return an integer
    public int get(int key) {
        if(!hs.containsKey(key)){
            return -1;
        }
        //remove to the tail
        Node current = hs.get(key);
        current.pre.next= current.next;
        current.next.pre= current.pre;
        //inset to tail
        move_to_tail(current);
        return current.value;
    }

    private void move_to_tail(Node current) {
        current.pre= tail.pre;
        current.next=tail;
        tail.pre= current;
        current.pre.next=current;
    }

    // @param key, an integer
    // @param value, an integer
    // @return nothing
    public void set(int key, int value) {
        //check if the node exist
        //not exist, if capacity is full, remove head.next
        //insert new node to tail
        if(get(key)!=-1){
            hs.get(key).value=value;
            return;
        }
        if( hs.size()==capacity){
            Node remove = head.next;
            head.next= head.next.next;
            head.next.pre= head;
            hs.remove(remove.key);

        }
        Node node = new Node(key,value);
        hs.put(key,node);
        move_to_tail(node);
        //tail.pre.next = current
        //tail .pre= current;
        //current.next= tail;

    }
}
