/**
 * 
 */
package list;
/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 

/**
 * @author Tiannan
 *
 */

public class ReverseLinkedList {
	public class ListNode {
	    int val;
	    ListNode next;
	    ListNode(int val) {
	        this.val = val;
	        this.next = null;
	    }
	}
	public static ListNode reverse(ListNode head){
		
		ListNode pre=null; 
		while (head!=null){
			ListNode temp= head.next;//store the next node
			head.next=pre;//current points to head
			pre=head;
			head=temp;
		}
		return pre;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
