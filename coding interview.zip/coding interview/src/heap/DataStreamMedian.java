/**
 *
 */
package heap;

import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * @author K25553
 *         median:maintain 3 lists, min mediant max
 *         onece add ele>median add max else add small
 *         if |ct min- ct max| = 2 median to small size side,
 *         extract top one from large size side to be the new median
 *
 *
 *
 */
public class DataStreamMedian {
	private PriorityQueue<Integer> max, min;

	/**
	 * @param nums
	 *            : A list of integers.
	 * @return: the median of numbers
	 */
	public int[] medianII(int[] nums) {
		Comparator<Integer> revComparator = new Comparator<Integer>() {

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.util.Comparator#compare(java.lang.Object,
			 * java.lang.Object)
			 */
			@Override
			public int compare(Integer o1, Integer o2) {

				return o2.compareTo(o1);
			}

		};
		int ct = nums.length;
		min = new PriorityQueue<Integer>(ct);
		max = new PriorityQueue<Integer>(ct, revComparator);
		int[] res = new int[ct];
		if (ct == 0 || nums == null) {
			return nums;
		}
		res[0] = nums[0];
		for (int i = 1; i < ct; i++) {
			if (nums[i] <= res[i - 1]) {
				max.add(nums[i]);
			} else {
				min.add(nums[i]);
			}
			if (max.size() - min.size() == 1) {
				res[i] = max.remove();
				min.add(res[i - 1]);
			} else if (min.size() - max.size() == 0
					|| min.size() - max.size() == 1) {
				res[i] = res[i - 1];
				continue;
			} else {
				res[i] = min.remove();
				max.add(res[i - 1]);
			}
		}
		return res;
	}

	private int numOfElements = 0;

	public int[] medianII2(int[] nums) {
		// write your code here
		Comparator<Integer> revCmp = new Comparator<Integer>() {
			@Override
			public int compare(Integer left, Integer right) {
				return right.compareTo(left);
			}
		};
		int cnt = nums.length;
		max = new PriorityQueue<Integer>(cnt, revCmp);
		min = new PriorityQueue<Integer>(cnt);
		int[] ans = new int[cnt];
		for (int i = 0; i < cnt; ++i) {
			addNumber(nums[i]);
			ans[i] = getMedian();
		}
		return ans;
	}

	void addNumber(int value) {
		// use the left top to store
		// star to add it to left, then if max left > min right then switch
		max.add(value);
		// if both side is not even, left +1 = right, then left top is median so
		// compare left and right top, if left is greater than right then swap
		// left and right,
		// if number is even than left- right =2 then left remove to be added to
		// right
		if (numOfElements % 2 == 0) {
			if (min.isEmpty()) {
				numOfElements++;
				return;
			} else if (max.peek() > min.peek()) {
				Integer maxRoot = max.poll();
				Integer minRoot = min.poll();
				max.add(minRoot);
				min.add(maxRoot);
			}
		} else {
			min.add(max.poll());
		}
		numOfElements++;
	}

	int getMedian() {
		return max.peek();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
