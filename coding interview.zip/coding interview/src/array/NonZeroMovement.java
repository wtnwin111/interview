package array;

import java.util.Arrays;

public class NonZeroMovement {
	
	public static int Manipulate(int[] a)
    {
        if (a.length < 1)
            return 0;
        int i = -1, m = 0;

        while (m < a.length)
        {
            if (a[m] != 0)
            {
                i += 1;
                a[i] = a[m];
            }
            m++;
        }
        int count = i + 1;
        while (i+1 < m)
        {
            i += 1;
            a[i] = 0;
        }

        return count;
    }
	public static void swap(int i, int j, int[]a){
		int temp= a[i];
		a[i]=a[j];
		a[j]=temp;
	}
	public static void main(String[] args) {
		int[] a= {0,1,3,0,0,3,5,7,0,5,0,4,4,0};
		//moveZero(a);
		int b= Manipulate(a);
		System.out.println(Arrays.toString(a));
	}
}
