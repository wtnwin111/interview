/**
 *
 */
package array;

/**
 * @author K25553
 *
 */
public class HashFunction {
	/**
	 * @param key
	 *            : A String you should hash
	 * @param HASH_SIZE
	 *            : An integer
	 * @return an integer
	 */
	public int hashCode(char[] key, int HASH_SIZE) {
		// write your code here
		long ans = 0;
		for (int i = 0; i < key.length; i++) {
			ans = (ans * 33 + (key[i])) % HASH_SIZE;
		}
		return (int) ans;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
