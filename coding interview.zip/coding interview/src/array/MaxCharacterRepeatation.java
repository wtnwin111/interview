/**
 * 
 */
package array;

import java.util.HashMap;

/**
 * @author Tiannan
 *
 */
public class MaxCharacterRepeatation {
	public static int MaxCharacterRepeatation(String a){
		HashMap h= new HashMap();
		char[] b= a.toCharArray();
		int max= Integer.MIN_VALUE;
	
		for (char c: b){
			if(h.containsKey(c)){
				int count=(int) h.get(c);
				h.put(c, count+1);
				
			}else{
				h.put(c, 1);
			}
			
		}
		
		for(char c: b){
			int count= (int) h.get(c);
			if (max<count){
				max=count;
			}
		}
		
		return max;
		
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s= "asdffffffff";
		System.out.println(MaxCharacterRepeatation(s));

	}

}
