package array;


//����һ�����飬����ÿ��Ԫ�ص�surpasser������
//����Ԫ��a��i����surpasser��ָԪ��a[j], j > i�� a[j] > a��i����
//����[10, 3, 7, 1, 23, 14, 6, 9] ���������10��surpasser��23��14��surpasser������2��
public class Surpasser {
	public static int surpasser(int[] arr){
		if(arr.length < 2)        return 0; 
		int[] surp = new int[arr.length];
		for(int i = 0; i < arr.length; ++i) {        surp[i] = 0;        }

		mergeSortHelper(arr, 0, arr.length, surp);

		int max = surp[0];
		for(int i = 0; i < arr.length; ++i) {
			max = Math.max(max, surp[i]);
		}

		return max;
	}

	public static int[][] mergeSortHelper(int[] arr, int st, int en, int[] surp) {                
		int[][] result = new int[2][en - st];
		if(en - st == 1) {
			result[0][0] = surp[st];
			result[1][0] = arr[st];
		} else {                

			int mid = st + (en - st) / 2;

			int[][] left = mergeSortHelper(arr, st, mid, surp);
			int[][] right = mergeSortHelper(arr, mid, en, surp);
			int i = 0, j  = 0, k = 0;

			while(i < left[0].length && j < right[0].length) {
				if(left[1][i] < right[1][j]) {
					result[0][k] = left[0][i] + right[0].length - j;
					result[1][k] = left[1][i];
					++i;
				} else {
					result[0][k] = right[0][j];
					result[1][k] = right[1][j];
					++j;
				}
				++k;
			}
			if(i < left[0].length){
				result[0][k] = left[0][i];
				result[1][k] = left[1][i];
				++i;
				++k;
			}

			if(j < right[0].length) {                        
				result[0][k] = right[0][j];
				result[1][k] = right[1][j];
				++j;
				++k;
			}

			for(int l = st; l < en; ++l){
				arr[l] = result[1][l - st];
				surp[l] = result[0][l - st];
			}
		}

		return result;
	} 

	public static void main(String[] args){
		int[] arr = new int[]{10, 3, 0, 7, 1, -1, 14, 23, 6, 9};
		System.out.println(surpasser(arr));
	}        
}
