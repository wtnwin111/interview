/**
 *
 */
package array;

import java.util.ArrayList;

/**
 * @author Tiannan
 *
 */
public class Permutations {
	public ArrayList<ArrayList<Integer>> permute(int[] num) {
		ArrayList<ArrayList<Integer>> rst = new ArrayList<ArrayList<Integer>>();
		if (num == null || num.length == 0) {
			return rst;
		}

		ArrayList<Integer> list = new ArrayList<Integer>();
		helper(rst, list, num);
		return rst;
	}

	public void helper(ArrayList<ArrayList<Integer>> rst,
			ArrayList<Integer> list, int[] num) {
		if (list.size() == num.length) {
			rst.add(new ArrayList<Integer>(list));
			return;
		}

		for (int i = 0; i < num.length; i++) {
			if (list.contains(num[i])) {
				continue;
			}
			list.add(num[i]);
			helper(rst, list, num);
			list.remove(list.size() - 1);
		}

	}

	public ArrayList<ArrayList<Integer>> permute(ArrayList<Integer> a) {
		ArrayList<ArrayList<Integer>> res = new ArrayList<ArrayList<Integer>>();
		if (a == null || a.size() == 0) {
			return res;
		}
		int visited[] = new int[a.size()];
		ArrayList<Integer> tempArrayList = new ArrayList<Integer>();
		dfs(a, res, tempArrayList, visited);
		return res;
	}

	private void dfs(ArrayList<Integer> a, ArrayList<ArrayList<Integer>> res,
			ArrayList<Integer> temp, int[] visited) {
		if (temp.size() == a.size()) {
			res.add(new ArrayList<Integer>(temp));
			return;
		}
		for (int i = 0; i < a.size(); i++) {
			if (visited[i] == 1) {
				continue;
			}
			visited[i] = 1;
			temp.add(a.get(i));
			dfs(a, res, temp, visited);
			visited[i] = 0;
			temp.remove(temp.size() - 1);
		}
	}

	/**
	 * @param args
	 */
	 public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
