/**
 *
 */
package array;

import java.util.List;

/**
 * @author K25553
 *
 */
public class PrintNumbersbyRecursion {
	/**
	 * @param n
	 *            : An integer.
	 *            return : An array storing 1 to the largest number with n
	 *            digits.
	 */
//	public List<Integer> numbersByRecursion(int n) {
//
//	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
