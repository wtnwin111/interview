/**
 *
 */
package sort;

/**
 * Given an integer array, sort it in ascending order. Use quick sort, merge
 * sort, heap sort or any O(nlogn) algorithm.
 *
 * @author K25553
 *
 */
public class SortIntegersII {
	/**
	 * @param A
	 *            an integer array
	 * @return void
	 */
	public void sortIntegers2(int[] a) {
		if (a == null || a.length == 0) {
			return;
		}
		quickSort(a, 0, a.length);
	}

	private void quickSort(int[] a, int i, int length) {
		// TODO Auto-generated method stub

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
